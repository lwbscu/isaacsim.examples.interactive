#!/usr/bin/env python3
"""
SVSDF扫掠体积感知轨迹规划系统完整演示

这是一个完整的演示脚本，展示了扫掠体积感知轨迹规划系统的所有功能：
1. A*路径规划可视化
2. MINCO轨迹优化动画
3. 扫掠体积3D可视化
4. MPC实时控制演示
5. 专业级性能监控HUD

使用方法：
1. 确保Isaac Sim已正确安装和配置
2. 运行此脚本：python svsdf_complete_demo.py
3. 观察完整的规划可视化流程
"""

import asyncio
import sys
import traceback
import argparse
from typing import Dict, List, Tuple, Any

# Isaac Sim imports
try:
    from omni.isaac.core import World
    from omni.isaac.core.utils.nucleus import get_assets_root_path
    from omni.isaac.core.utils.stage import add_reference_to_stage
    import omni.usd
    ISAAC_SIM_AVAILABLE = True
except ImportError:
    print("警告: Isaac Sim未找到，将使用模拟模式")
    ISAAC_SIM_AVAILABLE = False

# 导入SVSDF系统组件
try:
    from svsdf_visualization_controller import SVSDFVisualizationController, VisualizationConfig
    from professional_isaac_visualizer import ProfessionalIsaacVisualizer
except ImportError as e:
    print(f"警告: 无法导入SVSDF组件: {e}")
    print("请确保所有文件都在正确的路径中")

class SVSDFDemoRunner:
    """SVSDF演示运行器"""
    
    def __init__(self):
        self.world = None
        self.controller = None
        self.demo_scenarios = self._create_demo_scenarios()
        self.current_scenario = 0
    
    def _create_demo_scenarios(self) -> List[Dict[str, Any]]:
        """创建演示场景"""
        scenarios = [
            {
                "name": "基础导航场景",
                "description": "简单的点对点导航，展示基本的SVSDF功能",
                "start_pose": (-4.0, -3.0, 0.3),
                "goal_pose": (4.0, 3.0, 0.3),
                "obstacles": [
                    {'type': 'circle', 'center': [0.0, 0.0], 'radius': 1.0},
                    {'type': 'circle', 'center': [2.0, -1.0], 'radius': 0.6}
                ],
                "config": {
                    'astar_animation_speed': 0.02,
                    'minco_stage_delay': 1.5,
                    'mpc_update_frequency': 0.15
                }
            },
            {
                "name": "复杂环境挑战",
                "description": "多障碍物环境，测试高级规划能力",
                "start_pose": (-3.5, -2.5, 0.3),
                "goal_pose": (3.5, 2.5, 0.3),
                "obstacles": [
                    {'type': 'circle', 'center': [-1.0, 0.0], 'radius': 0.8},
                    {'type': 'circle', 'center': [1.0, 0.5], 'radius': 0.7},
                    {'type': 'circle', 'center': [0.0, -1.5], 'radius': 0.5},
                    {'type': 'circle', 'center': [2.5, 1.0], 'radius': 0.6},
                    {'type': 'circle', 'center': [-2.0, 1.5], 'radius': 0.4}
                ],
                "config": {
                    'astar_animation_speed': 0.015,\n                    'minco_stage_delay': 2.0,\n                    'mpc_update_frequency': 0.1\n                }\n            },\n            {\n                "name": "狭窄通道场景",\n                "description": "狭窄通道导航，展示扫掠体积感知的重要性",\n                "start_pose": (-4.0, 0.0, 0.3),\n                "goal_pose": (4.0, 0.0, 0.3),\n                "obstacles": [\n                    {'type': 'circle', 'center': [-1.0, 1.0], 'radius': 0.8},\n                    {'type': 'circle', 'center': [-1.0, -1.0], 'radius': 0.8},\n                    {'type': 'circle', 'center': [1.0, 1.0], 'radius': 0.8},\n                    {'type': 'circle', 'center': [1.0, -1.0], 'radius': 0.8}\n                ],\n                "config": {\n                    'astar_animation_speed': 0.025,\n                    'minco_stage_delay': 2.5,\n                    'mpc_update_frequency': 0.08\n                }\n            },\n            {\n                "name": "高速机动场景",\n                "description": "高速运动轨迹，展示MINCO优化和MPC控制",\n                "start_pose": (-3.0, -3.0, 0.3),\n                "goal_pose": (3.0, 3.0, 0.3),\n                "obstacles": [\n                    {'type': 'circle', 'center': [0.0, 0.0], 'radius': 1.2},\n                    {'type': 'circle', 'center': [-2.0, 2.0], 'radius': 0.5},\n                    {'type': 'circle', 'center': [2.0, -2.0], 'radius': 0.5}\n                ],\n                "config": {\n                    'astar_animation_speed': 0.01,\n                    'minco_stage_delay': 1.0,\n                    'mpc_update_frequency': 0.05\n                }\n            }\n        ]\n        \n        return scenarios\n    \n    async def initialize_isaac_sim(self, headless: bool = False):\n        """初始化Isaac Sim环境"""\n        if not ISAAC_SIM_AVAILABLE:\n            print("Isaac Sim不可用，无法运行演示")\n            return False\n        \n        try:\n            print("初始化Isaac Sim环境...")\n            \n            # 创建World实例\n            self.world = World(\n                stage_units_in_meters=1.0,\n                physics_dt=1.0/60.0,\n                rendering_dt=1.0/60.0\n            )\n            \n            # 添加默认地面\n            self.world.scene.add_default_ground_plane()\n            \n            # 设置相机视角\n            await self._setup_camera_view()\n            \n            # 设置照明\n            await self._setup_scene_lighting()\n            \n            print("Isaac Sim环境初始化完成")\n            return True\n            \n        except Exception as e:\n            print(f"Isaac Sim初始化失败: {e}")\n            traceback.print_exc()\n            return False\n    \n    async def _setup_camera_view(self):\n        """设置相机视角"""\n        try:\n            # 设置一个合适的俯视角度\n            camera_position = [0, -8, 6]\n            camera_target = [0, 0, 0]\n            \n            # 这里需要Isaac Sim特定的相机设置代码\n            # 由于版本差异，使用通用的USD相机设置\n            stage = omni.usd.get_context().get_stage()\n            \n            if stage:\n                # 创建相机\n                camera_prim_path = "/World/Camera"\n                camera_prim = stage.DefinePrim(camera_prim_path, "Camera")\n                \n                if camera_prim:\n                    from pxr import UsdGeom, Gf\n                    \n                    # 设置相机变换\n                    xform = UsdGeom.Xformable(camera_prim)\n                    transform_matrix = Gf.Matrix4d(\n                        1, 0, 0, 0,\n                        0, 1, 0, 0,\n                        0, 0, 1, 0,\n                        camera_position[0], camera_position[1], camera_position[2], 1\n                    )\n                    xform.AddTransformOp().Set(transform_matrix)\n            \n            print("相机视角设置完成")\n            \n        except Exception as e:\n            print(f"相机设置失败: {e}")  # 不致命错误，继续运行\n    \n    async def _setup_scene_lighting(self):\n        """设置场景照明"""\n        try:\n            stage = omni.usd.get_context().get_stage()\n            \n            if stage:\n                from pxr import UsdLux, Gf\n                \n                # 主光源\n                main_light_path = "/World/MainLight"\n                main_light_prim = stage.DefinePrim(main_light_path, "DomeLight")\n                \n                if main_light_prim:\n                    dome_light = UsdLux.DomeLight(main_light_prim)\n                    dome_light.CreateIntensityAttr(1000)\n                    dome_light.CreateColorAttr(Gf.Vec3f(1.0, 1.0, 1.0))\n            \n            print("场景照明设置完成")\n            \n        except Exception as e:\n            print(f"照明设置失败: {e}")  # 不致命错误，继续运行\n    \n    async def run_demo_scenario(self, scenario_index: int = None):\n        """运行指定的演示场景"""\n        if scenario_index is None:\n            scenario_index = self.current_scenario\n        \n        if not 0 <= scenario_index < len(self.demo_scenarios):\n            print(f"无效的场景索引: {scenario_index}")\n            return False\n        \n        scenario = self.demo_scenarios[scenario_index]\n        \n        print(f"\\n{'='*60}")\n        print(f"运行演示场景: {scenario['name']}")\n        print(f"描述: {scenario['description']}")\n        print(f"{'='*60}\\n")\n        \n        try:\n            # 创建可视化控制器\n            config = VisualizationConfig(**scenario['config'])\n            self.controller = SVSDFVisualizationController(self.world, config)\n            \n            # 运行完整的规划可视化\n            await self.controller.run_complete_planning_visualization(\n                scenario['start_pose'],\n                scenario['goal_pose'],\n                scenario['obstacles']\n            )\n            \n            print(f"场景 '{scenario['name']}' 演示完成")\n            \n            # 显示性能统计\n            status = self.controller.get_current_status()\n            self._print_scenario_summary(scenario, status)\n            \n            return True\n            \n        except Exception as e:\n            print(f"场景演示失败: {e}")\n            traceback.print_exc()\n            return False\n    \n    def _print_scenario_summary(self, scenario: Dict[str, Any], status: Dict[str, Any]):\n        """打印场景摘要"""\n        print(f"\\n场景摘要: {scenario['name']}")\n        print("-" * 40)\n        print(f"起点: {scenario['start_pose']}")\n        print(f"终点: {scenario['goal_pose']}")\n        print(f"障碍物数量: {len(scenario['obstacles'])}")\n        print(f"当前阶段: {status.get('current_phase', 'Unknown')}")\n        \n        if 'planning_statistics' in status:\n            stats = status['planning_statistics']\n            for phase, data in stats.items():\n                print(f"{phase}阶段统计:")\n                for key, value in data.items():\n                    if isinstance(value, float):\n                        print(f"  {key}: {value:.3f}")\n                    else:\n                        print(f"  {key}: {value}")\n        print("-" * 40)\n    \n    async def run_all_scenarios(self, pause_between: float = 5.0):\n        """运行所有演示场景"""\n        print("开始运行所有SVSDF演示场景...")\n        \n        for i, scenario in enumerate(self.demo_scenarios):\n            print(f"\\n准备运行场景 {i+1}/{len(self.demo_scenarios)}: {scenario['name']}")\n            \n            success = await self.run_demo_scenario(i)\n            \n            if not success:\n                print(f"场景 {i+1} 失败，跳过...")\n                continue\n            \n            if i < len(self.demo_scenarios) - 1:  # 不是最后一个场景\n                print(f"等待 {pause_between} 秒后运行下一个场景...")\n                await asyncio.sleep(pause_between)\n                \n                # 清理当前场景\n                if self.controller:\n                    self.controller.stop_visualization()\n        \n        print("\\n所有演示场景完成！")\n    \n    async def run_interactive_demo(self):\n        """运行交互式演示"""\n        print("\\n欢迎使用SVSDF交互式演示！")\n        print("可用命令:")\n        print("  1-4: 运行指定场景")\n        print("  a: 运行所有场景")\n        print("  s: 显示场景列表")\n        print("  q: 退出")\n        print("  h: 显示帮助")\n        \n        while True:\n            try:\n                command = input("\\n请输入命令 (h显示帮助): ").lower().strip()\n                \n                if command == 'q':\n                    print("退出演示")\n                    break\n                elif command == 'h':\n                    self._print_help()\n                elif command == 's':\n                    self._print_scenarios()\n                elif command == 'a':\n                    await self.run_all_scenarios()\n                elif command.isdigit():\n                    scenario_num = int(command) - 1\n                    if 0 <= scenario_num < len(self.demo_scenarios):\n                        await self.run_demo_scenario(scenario_num)\n                    else:\n                        print(f"无效的场景编号: {command}")\n                else:\n                    print(f"未知命令: {command}")\n                    \n            except KeyboardInterrupt:\n                print("\\n用户中断，退出演示")\n                break\n            except Exception as e:\n                print(f"命令执行错误: {e}")\n    \n    def _print_help(self):\n        """打印帮助信息"""\n        print("\\nSVSDF演示系统帮助:")\n        print("="*50)\n        print("这个演示系统展示了扫掠体积感知轨迹规划的完整流程：")\n        print("\\n阶段说明:")\n        print("1. A*路径规划 - 搜索初始路径")\n        print("2. MINCO轨迹优化 - 两阶段轨迹平滑")\n        print("3. 扫掠体积分析 - 3D体积可视化")\n        print("4. MPC控制 - 实时跟踪控制")\n        print("\\n可视化特性:")\n        print("- 专业级材质和光照效果")\n        print("- 实时性能监控HUD")\n        print("- 动态粒子效果")\n        print("- 分层可视化架构")\n        print("="*50)\n    \n    def _print_scenarios(self):\n        """打印可用场景列表"""\n        print("\\n可用演示场景:")\n        print("-"*60)\n        for i, scenario in enumerate(self.demo_scenarios):\n            print(f"{i+1}. {scenario['name']}")\n            print(f"   描述: {scenario['description']}")\n            print(f"   障碍物: {len(scenario['obstacles'])}个")\n            print()\n    \n    def cleanup(self):\n        """清理资源"""\n        try:\n            if self.controller:\n                self.controller.stop_visualization()\n            \n            if self.world:\n                self.world.stop()\n                \n            print("资源清理完成")\n            \n        except Exception as e:\n            print(f"清理时出错: {e}")\n\nasync def main():\n    """主函数"""\n    parser = argparse.ArgumentParser(description='SVSDF扫掠体积感知轨迹规划演示')\n    parser.add_argument('--scenario', type=int, help='运行指定场景 (1-4)')\n    parser.add_argument('--all', action='store_true', help='运行所有场景')\n    parser.add_argument('--interactive', action='store_true', help='交互模式')\n    parser.add_argument('--headless', action='store_true', help='无头模式运行')\n    \n    args = parser.parse_args()\n    \n    # 创建演示运行器\n    demo_runner = SVSDFDemoRunner()\n    \n    try:\n        # 初始化Isaac Sim\n        if not await demo_runner.initialize_isaac_sim(headless=args.headless):\n            print("初始化失败，退出")\n            return\n        \n        print("\\n🚀 SVSDF扫掠体积感知轨迹规划系统演示")\n        print("🎯 展示A*搜索、MINCO优化、扫掠体积分析、MPC控制")\n        print("✨ 专业级Isaac Sim可视化效果\\n")\n        \n        # 根据参数选择运行模式\n        if args.scenario:\n            # 运行指定场景\n            scenario_index = args.scenario - 1\n            await demo_runner.run_demo_scenario(scenario_index)\n            \n        elif args.all:\n            # 运行所有场景\n            await demo_runner.run_all_scenarios()\n            \n        elif args.interactive:\n            # 交互模式\n            await demo_runner.run_interactive_demo()\n            \n        else:\n            # 默认运行第一个场景\n            print("运行默认基础导航场景...")\n            await demo_runner.run_demo_scenario(0)\n            \n            # 询问是否继续\n            if input("\\n是否运行交互模式? (y/n): ").lower().startswith('y'):\n                await demo_runner.run_interactive_demo()\n        \n        print("\\n演示完成！感谢使用SVSDF系统！")\n        \n    except KeyboardInterrupt:\n        print("\\n用户中断演示")\n    except Exception as e:\n        print(f"演示运行出错: {e}")\n        traceback.print_exc()\n    finally:\n        # 清理资源\n        demo_runner.cleanup()\n\ndef run_quick_test():\n    """快速测试函数（不需要Isaac Sim）"""\n    print("SVSDF系统快速测试...")\n    \n    # 测试模块导入\n    modules_to_test = [\n        'svsdf_visualization_controller',\n        'professional_isaac_visualizer'\n    ]\n    \n    for module_name in modules_to_test:\n        try:\n            __import__(module_name)\n            print(f"✅ {module_name} - 导入成功")\n        except ImportError as e:\n            print(f"❌ {module_name} - 导入失败: {e}")\n    \n    # 测试场景配置\n    demo_runner = SVSDFDemoRunner()\n    scenarios = demo_runner.demo_scenarios\n    \n    print(f"\\n✅ 发现 {len(scenarios)} 个演示场景:")\n    for i, scenario in enumerate(scenarios):\n        print(f"  {i+1}. {scenario['name']}")\n    \n    print("\\n快速测试完成！")\n    print("运行完整演示请使用: python svsdf_complete_demo.py")\n\nif __name__ == "__main__":\n    if '--test' in sys.argv:\n        # 快速测试模式\n        run_quick_test()\n    else:\n        # 运行完整演示\n        try:\n            asyncio.run(main())\n        except Exception as e:\n            print(f"程序异常退出: {e}")\n            sys.exit(1)
