#!/usr/bin/env python3
"""
SVSDF轨迹规划可视化控制器

整合专业级Isaac Sim可视化系统与扫掠体积感知轨迹规划器，
提供完整的视觉化轨迹规划、优化、控制和分析流程。
"""

import numpy as np
import asyncio
import time
from typing import List, Dict, Tuple, Optional, Any
from dataclasses import dataclass
from enum import Enum

# Isaac Sim imports
from omni.isaac.core import World
from omni.isaac.core.objects import VisualCuboid, VisualSphere

# 导入SVSDF系统组件
try:
    from .professional_isaac_visualizer import ProfessionalIsaacVisualizer, VisualizationMode
    from .SweptVolumePlanner的完整实现 import SweptVolumePlanner
    from .模型预测控制器（MPC） import MPCController
    from .扫掠体积感知轨迹规划器完整测试套件 import SVSDFTestSuite
except ImportError:
    print("警告: 无法导入SVSDF系统组件，使用模拟实现")

@dataclass
class VisualizationConfig:
    """可视化配置"""
    # 动画时间设置
    astar_animation_speed: float = 0.01  # A*搜索动画速度(秒)
    minco_stage_delay: float = 1.0       # MINCO阶段间延迟(秒)
    mpc_update_frequency: float = 0.1    # MPC更新频率(秒)
    
    # 可视化质量设置
    trajectory_point_density: int = 5    # 轨迹点密度（每N个点显示一个）
    particle_count: int = 20            # 粒子效果数量
    hud_update_frequency: float = 0.5   # HUD更新频率(秒)
    
    # 调试设置
    show_debug_info: bool = True        # 显示调试信息
    save_visualization_data: bool = False # 保存可视化数据
    enable_performance_monitoring: bool = True # 启用性能监控

class SVSDFVisualizationController:
    """SVSDF可视化控制器"""
    
    def __init__(self, world: World, config: VisualizationConfig = None):
        self.world = world
        self.config = config or VisualizationConfig()
        
        # 初始化专业可视化系统
        self.visualizer = ProfessionalIsaacVisualizer(world)
        
        # 规划器组件（如果可用）
        self.planner = None
        self.mpc_controller = None
        
        # 状态追踪
        self.current_phase = "idle"
        self.planning_statistics = {}
        self.visualization_data = {}
        
        # 异步任务管理
        self.running_tasks = []
        self.is_running = False
        
        print("SVSDF可视化控制器初始化完成")
    
    def initialize_planner(self, planner_config: Dict[str, Any]):
        """初始化规划器"""
        try:
            # 这里应该使用实际的规划器类
            # self.planner = SweptVolumePlanner(planner_config)
            # self.mpc_controller = MPCController(planner_config.get('mpc', {}))
            print("规划器初始化成功")
        except Exception as e:
            print(f"规划器初始化失败: {e}")
    
    async def run_complete_planning_visualization(self, 
                                                start_pose: Tuple[float, float, float],
                                                goal_pose: Tuple[float, float, float],
                                                obstacles: List[Dict[str, Any]]):
        """运行完整的规划可视化流程"""
        print("开始完整SVSDF规划可视化流程...")
        
        self.is_running = True
        start_time = time.time()
        
        try:
            # 设置环境
            await self._setup_environment(obstacles)
            
            # 阶段1: A*路径规划
            await self._phase_astar_planning(start_pose, goal_pose, obstacles)
            
            # 阶段2: MINCO轨迹优化
            await self._phase_minco_optimization()
            
            # 阶段3: 扫掠体积分析
            await self._phase_swept_volume_analysis()
            
            # 阶段4: MPC跟踪控制
            await self._phase_mpc_control()
            
            # 性能分析
            await self._phase_performance_analysis()
            
            total_time = time.time() - start_time
            print(f"完整规划可视化流程完成，总耗时: {total_time:.2f}秒")
            
        except Exception as e:
            print(f"规划可视化流程出错: {e}")
        finally:
            self.is_running = False
    
    async def _setup_environment(self, obstacles: List[Dict[str, Any]]):
        """设置环境和障碍物"""
        print("设置环境...")
        
        # 创建地面网格
        await self._create_ground_grid()
        
        # 创建障碍物
        for i, obstacle in enumerate(obstacles):
            await self._create_obstacle_visualization(i, obstacle)
        
        # 更新HUD显示环境状态
        env_metrics = {
            'obstacle_count': len(obstacles),
            'environment_complexity': self._calculate_environment_complexity(obstacles)
        }
        
        print(f"环境设置完成: {len(obstacles)}个障碍物")
    
    async def _create_ground_grid(self):
        """创建地面网格"""
        grid_size = 20
        cell_size = 0.5
        
        for i in range(grid_size):
            for j in range(grid_size):
                if (i + j) % 2 == 0:  # 棋盘格模式
                    continue
                    
                grid_path = f"/World/Environment/Grid/cell_{i}_{j}"
                cell_position = [(i - grid_size/2) * cell_size, 
                               (j - grid_size/2) * cell_size, 
                               -0.01]
                
                cell = VisualCuboid(
                    prim_path=grid_path,
                    name=f"grid_cell_{i}_{j}",
                    position=np.array(cell_position),
                    size=np.array([cell_size * 0.9, cell_size * 0.9, 0.005]),
                    color=np.array([0.8, 0.8, 0.9])
                )
                
                # 应用半透明材质
                material = self.visualizer.material_library.create_custom_material(
                    (0.8, 0.8, 0.9), "glass"
                )
                if material:
                    cell.apply_visual_material(material)
    
    async def _create_obstacle_visualization(self, obstacle_id: int, obstacle: Dict[str, Any]):
        """创建障碍物可视化"""
        obstacle_type = obstacle.get('type', 'circle')
        position = obstacle.get('center', [0, 0, 0])
        
        if obstacle_type == 'circle':
            radius = obstacle.get('radius', 0.5)
            
            # 主障碍物
            obs_path = f"/World/Environment/Obstacles/obstacle_{obstacle_id}"
            obs_sphere = VisualSphere(
                prim_path=obs_path,
                name=f"obstacle_{obstacle_id}",
                position=np.array([position[0], position[1], 0.2]),
                radius=radius,
                color=np.array(self.visualizer.color_scheme.obstacle)
            )
            
            # 应用金属材质
            material = self.visualizer.material_library.get_material("metallic")
            if material:
                obs_sphere.apply_visual_material(material)
            
            # 安全区域指示
            safety_radius = radius + 0.5  # 安全边距
            safety_path = f"/World/Environment/SafetyZones/safety_{obstacle_id}"
            safety_zone = VisualSphere(
                prim_path=safety_path,
                name=f"safety_zone_{obstacle_id}",
                position=np.array([position[0], position[1], 0.05]),
                radius=safety_radius,
                color=np.array([1.0, 0.8, 0.0])
            )
            
            # 应用半透明玻璃材质
            safety_material = self.visualizer.material_library.create_custom_material(
                (1.0, 0.8, 0.0), "glass"
            )
            if safety_material:
                safety_zone.apply_visual_material(safety_material)
    
    async def _phase_astar_planning(self, start_pose: Tuple[float, float, float], 
                                  goal_pose: Tuple[float, float, float],
                                  obstacles: List[Dict[str, Any]]):
        """A*路径规划阶段"""
        print("开始A*路径规划阶段...")
        
        self.current_phase = "astar_planning"
        self.visualizer.set_visualization_mode(VisualizationMode.PLANNING)
        
        # 更新性能HUD
        await self._update_hud_phase_info("A*路径规划")
        
        # 生成或获取A*搜索数据
        planning_data = await self._generate_astar_data(start_pose, goal_pose, obstacles)
        
        # 可视化A*搜索过程
        await self.visualizer.visualize_astar_search(
            planning_data['grid_map'],
            planning_data['search_nodes'],
            planning_data['final_path']
        )
        
        # 记录规划统计
        self.planning_statistics['astar'] = {
            'nodes_explored': len(planning_data['search_nodes']),
            'path_length': self._calculate_path_length(planning_data['final_path']),
            'computation_time': planning_data.get('computation_time', 0.0)
        }
        
        print("A*路径规划阶段完成")
    
    async def _phase_minco_optimization(self):
        """MINCO轨迹优化阶段"""
        print("开始MINCO轨迹优化阶段...")
        
        self.current_phase = "minco_optimization"
        self.visualizer.set_visualization_mode(VisualizationMode.OPTIMIZATION)
        
        await self._update_hud_phase_info("MINCO轨迹优化")
        
        # 生成或获取MINCO优化数据
        optimization_data = await self._generate_minco_data()
        
        # 可视化MINCO优化过程
        await self.visualizer.visualize_minco_optimization(
            optimization_data['initial_trajectory'],
            optimization_data['stage1_result'],
            optimization_data['stage2_result'],
            optimization_data['final_trajectory']
        )
        
        # 记录优化统计
        self.planning_statistics['minco'] = {
            'stage1_iterations': optimization_data.get('stage1_iterations', 0),
            'stage2_iterations': optimization_data.get('stage2_iterations', 0),
            'cost_reduction': optimization_data.get('cost_reduction', 0.0),
            'optimization_time': optimization_data.get('optimization_time', 0.0)
        }
        
        print("MINCO轨迹优化阶段完成")
    
    async def _phase_swept_volume_analysis(self):
        """扫掠体积分析阶段"""
        print("开始扫掠体积分析阶段...")
        
        self.current_phase = "swept_volume_analysis"
        
        await self._update_hud_phase_info("扫掠体积分析")
        
        # 生成或获取扫掠体积数据
        swept_data = await self._generate_swept_volume_data()
        
        # 可视化扫掠体积
        await self.visualizer.visualize_swept_volume(
            swept_data['robot_poses'],
            swept_data['swept_boundary'],
            swept_data['density_field']
        )
        
        # 记录扫掠体积统计
        self.planning_statistics['swept_volume'] = {
            'total_volume': swept_data.get('total_volume', 0.0),
            'boundary_points': len(swept_data['swept_boundary']),
            'volume_computation_time': swept_data.get('computation_time', 0.0)
        }
        
        print("扫掠体积分析阶段完成")
    
    async def _phase_mpc_control(self):
        """MPC跟踪控制阶段"""
        print("开始MPC跟踪控制阶段...")
        
        self.current_phase = "mpc_control"
        self.visualizer.set_visualization_mode(VisualizationMode.EXECUTION)
        
        await self._update_hud_phase_info("MPC跟踪控制")
        
        # 生成或获取MPC控制序列
        mpc_data = await self._generate_mpc_data()
        
        # 运行MPC控制可视化
        control_errors = []
        for i, control_step in enumerate(mpc_data['control_sequence']):\n            robot_pos = control_step['robot_position']\n            pred_traj = control_step['predicted_trajectory']\n            ref_traj = control_step['reference_trajectory']\n            error = control_step['tracking_error']\n            \n            control_errors.append(error)\n            \n            # 可视化MPC控制\n            await self.visualizer.visualize_mpc_control(\n                robot_pos, pred_traj, ref_traj, error\n            )\n            \n            # 实时更新性能指标\n            current_metrics = {\n                'control_error': {\n                    'value': error * 100, \n                    'status': 'good' if error < 0.1 else 'warning' if error < 0.3 else 'error'\n                },\n                'mpc_step': {'value': i + 1, 'status': 'good'},\n                'prediction_horizon': {'value': len(pred_traj), 'status': 'good'}\n            }\n            self.visualizer.update_performance_metrics(current_metrics)\n            \n            await asyncio.sleep(self.config.mpc_update_frequency)\n        \n        # 记录MPC统计\n        self.planning_statistics['mpc'] = {\n            'total_steps': len(mpc_data['control_sequence']),\n            'average_error': np.mean(control_errors) if control_errors else 0.0,\n            'max_error': np.max(control_errors) if control_errors else 0.0,\n            'control_frequency': 1.0 / self.config.mpc_update_frequency\n        }\n        \n        print("MPC跟踪控制阶段完成")\n    \n    async def _phase_performance_analysis(self):\n        """性能分析阶段"""\n        print("开始性能分析阶段...")\n        \n        self.current_phase = "performance_analysis"\n        self.visualizer.set_visualization_mode(VisualizationMode.ANALYSIS)\n        \n        await self._update_hud_phase_info("性能分析")\n        \n        # 汇总所有阶段的性能数据\n        comprehensive_metrics = self._compile_comprehensive_metrics()\n        \n        # 更新完整的性能HUD\n        self.visualizer.update_performance_metrics(comprehensive_metrics)\n        \n        # 如果启用，保存可视化数据\n        if self.config.save_visualization_data:\n            await self._save_visualization_data()\n        \n        # 显示性能分析结果\n        self._print_performance_summary()\n        \n        print("性能分析阶段完成")\n    \n    async def _update_hud_phase_info(self, phase_name: str):\n        """更新HUD显示当前阶段信息"""\n        phase_metrics = {\n            'current_phase': {'value': phase_name, 'status': 'good'},\n            'total_time': {'value': time.time() - getattr(self, '_start_time', time.time()), 'status': 'good'}\n        }\n        self.visualizer.update_performance_metrics(phase_metrics)\n    \n    def _compile_comprehensive_metrics(self) -> Dict[str, Any]:\n        """编译综合性能指标"""\n        metrics = {}\n        \n        # A*规划指标\n        if 'astar' in self.planning_statistics:\n            astar_stats = self.planning_statistics['astar']\n            metrics['planning_time'] = {\n                'value': astar_stats.get('computation_time', 0.0),\n                'status': 'good' if astar_stats.get('computation_time', 0.0) < 1.0 else 'warning'\n            }\n            metrics['nodes_explored'] = {\n                'value': astar_stats.get('nodes_explored', 0),\n                'status': 'good'\n            }\n        \n        # MINCO优化指标\n        if 'minco' in self.planning_statistics:\n            minco_stats = self.planning_statistics['minco']\n            metrics['optimization_time'] = {\n                'value': minco_stats.get('optimization_time', 0.0),\n                'status': 'good' if minco_stats.get('optimization_time', 0.0) < 5.0 else 'warning'\n            }\n            metrics['cost_reduction'] = {\n                'value': minco_stats.get('cost_reduction', 0.0) * 100,\n                'status': 'good' if minco_stats.get('cost_reduction', 0.0) > 0.1 else 'warning'\n            }\n        \n        # 扫掠体积指标\n        if 'swept_volume' in self.planning_statistics:\n            swept_stats = self.planning_statistics['swept_volume']\n            metrics['swept_volume'] = {\n                'value': swept_stats.get('total_volume', 0.0),\n                'status': 'good'\n            }\n            metrics['volume_computation'] = {\n                'value': swept_stats.get('volume_computation_time', 0.0),\n                'status': 'good' if swept_stats.get('volume_computation_time', 0.0) < 2.0 else 'warning'\n            }\n        \n        # MPC控制指标\n        if 'mpc' in self.planning_statistics:\n            mpc_stats = self.planning_statistics['mpc']\n            metrics['control_error'] = {\n                'value': mpc_stats.get('average_error', 0.0) * 100,\n                'status': 'good' if mpc_stats.get('average_error', 0.0) < 0.1 else 'warning'\n            }\n            metrics['max_error'] = {\n                'value': mpc_stats.get('max_error', 0.0) * 100,\n                'status': 'good' if mpc_stats.get('max_error', 0.0) < 0.2 else 'error'\n            }\n        \n        return metrics\n    \n    def _print_performance_summary(self):\n        """打印性能摘要"""\n        print("\\n" + "="*60)\n        print("SVSDF规划性能摘要")\n        print("="*60)\n        \n        for phase, stats in self.planning_statistics.items():\n            print(f"\\n{phase.upper()}阶段:")\n            for key, value in stats.items():\n                if isinstance(value, float):\n                    print(f"  {key}: {value:.3f}")\n                else:\n                    print(f"  {key}: {value}")\n        \n        print("\\n" + "="*60)\n    \n    async def _save_visualization_data(self):\n        """保存可视化数据"""\n        try:\n            import json\n            \n            # 准备保存的数据\n            save_data = {\n                'timestamp': time.time(),\n                'planning_statistics': self.planning_statistics,\n                'configuration': {\n                    'animation_speed': self.config.astar_animation_speed,\n                    'minco_delay': self.config.minco_stage_delay,\n                    'mpc_frequency': self.config.mpc_update_frequency\n                }\n            }\n            \n            # 保存到文件\n            filename = f"svsdf_visualization_{int(time.time())}.json"\n            with open(filename, 'w') as f:\n                json.dump(save_data, f, indent=2)\n            \n            print(f"可视化数据已保存到: {filename}")\n            \n        except Exception as e:\n            print(f"保存可视化数据失败: {e}")\n    \n    # 数据生成方法（模拟实现，实际使用时替换为真实规划器数据）\n    \n    async def _generate_astar_data(self, start_pose, goal_pose, obstacles) -> Dict[str, Any]:\n        """生成A*搜索数据"""\n        # 创建网格地图\n        grid_size = 50\n        grid_map = np.zeros((grid_size, grid_size))\n        \n        # 添加障碍物到网格\n        for obstacle in obstacles:\n            if obstacle.get('type') == 'circle':\n                center = obstacle['center']\n                radius = obstacle['radius']\n                \n                # 简化：将圆形障碍物映射到网格\n                grid_x = int((center[0] + 5) * grid_size / 10)  # 假设-5到5的坐标范围\n                grid_y = int((center[1] + 5) * grid_size / 10)\n                grid_radius = int(radius * grid_size / 10)\n                \n                for i in range(max(0, grid_x - grid_radius), min(grid_size, grid_x + grid_radius)):\n                    for j in range(max(0, grid_y - grid_radius), min(grid_size, grid_y + grid_radius)):\n                        if (i - grid_x)**2 + (j - grid_y)**2 <= grid_radius**2:\n                            grid_map[j, i] = 1\n        \n        # 生成搜索节点序列\n        search_nodes = []\n        num_nodes = 100\n        \n        for i in range(num_nodes):\n            progress = i / num_nodes\n            # 从起点到终点的插值，加上一些随机扰动\n            x = start_pose[0] + (goal_pose[0] - start_pose[0]) * progress + np.random.normal(0, 0.5)\n            y = start_pose[1] + (goal_pose[1] - start_pose[1]) * progress + np.random.normal(0, 0.5)\n            \n            status = 'open' if i < num_nodes * 0.3 else 'closed' if i < num_nodes * 0.9 else 'current'\n            \n            search_nodes.append({\n                'x': x,\n                'y': y,\n                'status': status\n            })\n        \n        # 生成最终路径\n        path_points = 20\n        final_path = []\n        for i in range(path_points):\n            progress = i / (path_points - 1)\n            x = start_pose[0] + (goal_pose[0] - start_pose[0]) * progress\n            y = start_pose[1] + (goal_pose[1] - start_pose[1]) * progress\n            final_path.append((x, y))\n        \n        return {\n            'grid_map': grid_map,\n            'search_nodes': search_nodes,\n            'final_path': final_path,\n            'computation_time': 0.15  # 模拟计算时间\n        }\n    \n    async def _generate_minco_data(self) -> Dict[str, Any]:\n        """生成MINCO优化数据"""\n        # 使用三角函数生成平滑轨迹\n        t = np.linspace(0, 2*np.pi, 30)\n        base_x = 2 * np.cos(t)\n        base_y = 2 * np.sin(t)\n        base_z = np.ones_like(t) * 0.3\n        \n        # 初始轨迹（比较粗糙）\n        initial_trajectory = list(zip(\n            base_x + 0.3 * np.random.random(len(t)),\n            base_y + 0.3 * np.random.random(len(t)),\n            base_z\n        ))\n        \n        # 阶段1优化（减少一些随机性）\n        stage1_result = list(zip(\n            base_x + 0.15 * np.random.random(len(t)),\n            base_y + 0.15 * np.random.random(len(t)),\n            base_z\n        ))\n        \n        # 阶段2优化（进一步优化）\n        stage2_result = list(zip(\n            base_x + 0.05 * np.random.random(len(t)),\n            base_y + 0.05 * np.random.random(len(t)),\n            base_z\n        ))\n        \n        # 最终轨迹（最平滑）\n        final_trajectory = list(zip(base_x, base_y, base_z))\n        \n        return {\n            'initial_trajectory': initial_trajectory,\n            'stage1_result': stage1_result,\n            'stage2_result': stage2_result,\n            'final_trajectory': final_trajectory,\n            'stage1_iterations': 25,\n            'stage2_iterations': 15,\n            'cost_reduction': 0.35,\n            'optimization_time': 2.8\n        }\n    \n    async def _generate_swept_volume_data(self) -> Dict[str, Any]:\n        """生成扫掠体积数据"""\n        # 获取机器人轨迹\n        if 'minco' in self.planning_statistics:\n            # 使用MINCO的最终轨迹\n            trajectory_data = await self._generate_minco_data()\n            trajectory = trajectory_data['final_trajectory']\n        else:\n            # 生成默认轨迹\n            t = np.linspace(0, 2*np.pi, 30)\n            trajectory = list(zip(2*np.cos(t), 2*np.sin(t), np.ones_like(t)*0.3))\n        \n        # 生成机器人姿态序列\n        robot_poses = []\n        for i, point in enumerate(trajectory):\n            # 计算朝向角度\n            if i < len(trajectory) - 1:\n                next_point = trajectory[i + 1]\n                theta = np.arctan2(next_point[1] - point[1], next_point[0] - point[0])\n            else:\n                theta = 0.0\n            \n            robot_poses.append({\n                'x': point[0],\n                'y': point[1],\n                'z': point[2],\n                'theta': theta\n            })\n        \n        # 计算扫掠边界（简化的凸包）\n        x_coords = [pose['x'] for pose in robot_poses]\n        y_coords = [pose['y'] for pose in robot_poses]\n        \n        # 添加机器人尺寸的边距\n        robot_width = 0.4\n        robot_length = 0.6\n        margin = max(robot_width, robot_length) / 2 + 0.1\n        \n        swept_boundary = [\n            (min(x_coords) - margin, min(y_coords) - margin),\n            (max(x_coords) + margin, min(y_coords) - margin),\n            (max(x_coords) + margin, max(y_coords) + margin),\n            (min(x_coords) - margin, max(y_coords) + margin)\n        ]\n        \n        # 生成密度场\n        field_size = 50\n        density_field = np.zeros((field_size, field_size))\n        \n        # 在轨迹附近设置较高的密度\n        for pose in robot_poses:\n            grid_x = int((pose['x'] + 5) * field_size / 10)\n            grid_y = int((pose['y'] + 5) * field_size / 10)\n            \n            if 0 <= grid_x < field_size and 0 <= grid_y < field_size:\n                # 高斯分布的密度\n                for i in range(max(0, grid_x-5), min(field_size, grid_x+5)):\n                    for j in range(max(0, grid_y-5), min(field_size, grid_y+5)):\n                        distance = np.sqrt((i-grid_x)**2 + (j-grid_y)**2)\n                        density_field[j, i] += np.exp(-distance**2 / 8)\n        \n        # 计算总体积\n        total_volume = float(np.sum(density_field) * 0.1 * 0.1 * 0.3)  # 网格大小 × 高度\n        \n        return {\n            'robot_poses': robot_poses,\n            'swept_boundary': swept_boundary,\n            'density_field': density_field,\n            'total_volume': total_volume,\n            'computation_time': 1.2\n        }\n    \n    async def _generate_mpc_data(self) -> Dict[str, Any]:\n        """生成MPC控制数据"""\n        # 获取参考轨迹\n        swept_data = await self._generate_swept_volume_data()\n        reference_poses = swept_data['robot_poses']\n        \n        control_sequence = []\n        \n        for i, ref_pose in enumerate(reference_poses):\n            # 模拟机器人实际位置（带有小的跟踪误差）\n            tracking_error = 0.02 + 0.08 * np.random.random()\n            error_angle = np.random.uniform(0, 2*np.pi)\n            \n            actual_x = ref_pose['x'] + tracking_error * np.cos(error_angle)\n            actual_y = ref_pose['y'] + tracking_error * np.sin(error_angle)\n            actual_z = ref_pose['z']\n            \n            robot_position = (actual_x, actual_y, actual_z)\n            \n            # 预测轨迹（未来几步）\n            prediction_horizon = 10\n            predicted_trajectory = []\n            for j in range(prediction_horizon):\n                if i + j < len(reference_poses):\n                    future_pose = reference_poses[i + j]\n                    predicted_trajectory.append((future_pose['x'], future_pose['y'], future_pose['z']))\n                else:\n                    # 延伸最后一个点\n                    predicted_trajectory.append(predicted_trajectory[-1] if predicted_trajectory else robot_position)\n            \n            # 参考轨迹（当前周围几步）\n            reference_horizon = 5\n            reference_trajectory = []\n            for j in range(reference_horizon):\n                if i + j < len(reference_poses):\n                    ref_pose_j = reference_poses[i + j]\n                    reference_trajectory.append((ref_pose_j['x'], ref_pose_j['y'], ref_pose_j['z']))\n                else:\n                    reference_trajectory.append(reference_trajectory[-1] if reference_trajectory else robot_position)\n            \n            control_step = {\n                'robot_position': robot_position,\n                'predicted_trajectory': predicted_trajectory,\n                'reference_trajectory': reference_trajectory,\n                'tracking_error': tracking_error\n            }\n            \n            control_sequence.append(control_step)\n        \n        return {\n            'control_sequence': control_sequence\n        }\n    \n    def _calculate_path_length(self, path: List[Tuple[float, float]]) -> float:\n        """计算路径长度"""\n        if len(path) < 2:\n            return 0.0\n        \n        total_length = 0.0\n        for i in range(1, len(path)):\n            dx = path[i][0] - path[i-1][0]\n            dy = path[i][1] - path[i-1][1]\n            total_length += np.sqrt(dx**2 + dy**2)\n        \n        return total_length\n    \n    def _calculate_environment_complexity(self, obstacles: List[Dict[str, Any]]) -> float:\n        """计算环境复杂度"""\n        # 简化的复杂度计算：基于障碍物数量和大小\n        complexity = 0.0\n        \n        for obstacle in obstacles:\n            if obstacle.get('type') == 'circle':\n                radius = obstacle.get('radius', 0.5)\n                complexity += radius * 2  # 半径越大，复杂度越高\n        \n        return complexity / max(len(obstacles), 1)  # 平均复杂度\n    \n    def stop_visualization(self):\n        """停止可视化"""\n        self.is_running = False\n        \n        # 停止所有异步任务\n        for task in self.running_tasks:\n            if not task.done():\n                task.cancel()\n        \n        # 清理可视化对象\n        self.visualizer.cleanup_all()\n        \n        print("可视化系统已停止")\n    \n    def get_current_status(self) -> Dict[str, Any]:\n        """获取当前状态"""\n        return {\n            'current_phase': self.current_phase,\n            'is_running': self.is_running,\n            'planning_statistics': self.planning_statistics,\n            'active_tasks': len([t for t in self.running_tasks if not t.done()])\n        }\n\n# 使用示例和主要接口函数\n\nasync def demo_svsdf_visualization():\n    """演示SVSDF完整可视化系统"""\n    from omni.isaac.core import World\n    \n    # 初始化Isaac Sim world\n    world = World(stage_units_in_meters=1.0)\n    world.scene.add_default_ground_plane()\n    \n    # 创建SVSDF可视化控制器\n    config = VisualizationConfig(\n        astar_animation_speed=0.02,\n        minco_stage_delay=2.0,\n        mpc_update_frequency=0.2,\n        show_debug_info=True\n    )\n    \n    controller = SVSDFVisualizationController(world, config)\n    \n    # 定义场景\n    start_pose = (-3.0, -2.0, 0.3)\n    goal_pose = (3.0, 2.0, 0.3)\n    obstacles = [\n        {'type': 'circle', 'center': [0.0, 0.0], 'radius': 0.8},\n        {'type': 'circle', 'center': [2.0, 1.0], 'radius': 0.5},\n        {'type': 'circle', 'center': [-1.5, 1.5], 'radius': 0.6}\n    ]\n    \n    try:\n        # 运行完整的规划可视化\n        await controller.run_complete_planning_visualization(\n            start_pose, goal_pose, obstacles\n        )\n        \n        # 保持可视化显示\n        print("可视化演示完成，按Ctrl+C停止...")\n        await asyncio.sleep(30.0)\n        \n    except KeyboardInterrupt:\n        print("用户中断")\n    except Exception as e:\n        print(f"演示出错: {e}")\n    finally:\n        # 清理\n        controller.stop_visualization()\n        world.stop()\n\n# 交互式接口函数\n\ndef create_svsdf_visualizer(world: World, \n                           config_dict: Dict[str, Any] = None) -> SVSDFVisualizationController:\n    """创建SVSDF可视化器的便捷函数"""\n    if config_dict:\n        config = VisualizationConfig(**config_dict)\n    else:\n        config = VisualizationConfig()\n    \n    return SVSDFVisualizationController(world, config)\n\nasync def run_quick_demo(world: World, \n                       start: Tuple[float, float, float],\n                       goal: Tuple[float, float, float],\n                       obstacles: List[Dict[str, Any]] = None):\n    """快速演示函数"""\n    if obstacles is None:\n        obstacles = [\n            {'type': 'circle', 'center': [1.0, 1.0], 'radius': 0.5}\n        ]\n    \n    controller = create_svsdf_visualizer(world)\n    \n    try:\n        await controller.run_complete_planning_visualization(start, goal, obstacles)\n        return controller.get_current_status()\n    except Exception as e:\n        print(f"快速演示失败: {e}")\n        return None\n    finally:\n        controller.stop_visualization()\n\nif __name__ == "__main__":\n    # 运行演示\n    asyncio.run(demo_svsdf_visualization())
