#!/usr/bin/env python3
"""
专业级Isaac Sim扫掠体积感知轨迹规划可视化系统

功能特性：
1. 高级材质和光照系统 - 发光材质、玻璃效果、全息投影效果
2. 分层可视化架构 - 规划、优化、控制、UI分层
3. 动态动画系统 - A*搜索、MINCO优化、MPC控制动画
4. 3D扫掠体积可视化 - 密度场、边界力场、体积指示器
5. 专业性能HUD - 实时指标、状态监控、控制面板
6. 粒子效果系统 - 轨迹粒子、优化收敛效果、控制反馈
"""

import numpy as np
import asyncio
import math
import time
from typing import List, Dict, Tuple, Optional, Any
from dataclasses import dataclass
from enum import Enum

# Isaac Sim imports - 使用正确的API路径
from omni.isaac.core import World
from omni.isaac.core.objects import VisualCuboid, VisualSphere, VisualCylinder
from omni.isaac.core.materials import VisualMaterial, PreviewSurface, OmniPBR, OmniGlass
from omni.isaac.core.prims import XFormPrim, GeometryPrim
from omni.isaac.core.utils.prims import create_prim, get_prim_at_path
from omni.isaac.core.utils.stage import get_current_stage
import omni.usd
from pxr import Usd, UsdGeom, UsdShade, UsdLux, Gf, Sdf, UsdPhysics

class VisualizationMode(Enum):
    """可视化模式枚举"""
    PLANNING = "planning"
    OPTIMIZATION = "optimization"
    EXECUTION = "execution"
    ANALYSIS = "analysis"

@dataclass
class ColorScheme:
    """专业配色方案"""
    # 规划阶段颜色
    astar_search: Tuple[float, float, float] = (0.3, 0.7, 1.0)      # 蓝色
    astar_nodes: Tuple[float, float, float] = (0.8, 0.9, 1.0)       # 浅蓝
    initial_path: Tuple[float, float, float] = (0.7, 0.7, 0.7)      # 灰色
    
    # 优化阶段颜色
    minco_stage1: Tuple[float, float, float] = (1.0, 0.8, 0.3)      # 黄色
    minco_stage2: Tuple[float, float, float] = (0.3, 1.0, 0.3)      # 绿色
    final_trajectory: Tuple[float, float, float] = (1.0, 0.8, 0.0)  # 金色
    
    # 控制阶段颜色
    mpc_prediction: Tuple[float, float, float] = (1.0, 0.3, 0.8)    # 品红
    mpc_trajectory: Tuple[float, float, float] = (0.8, 0.3, 1.0)    # 紫色
    
    # 物理对象颜色
    robot: Tuple[float, float, float] = (1.0, 0.5, 0.0)             # 橙色
    obstacle: Tuple[float, float, float] = (0.8, 0.3, 0.3)          # 红色
    swept_volume: Tuple[float, float, float] = (0.0, 0.8, 1.0)      # 青色
    
    # 性能指标颜色
    good_performance: Tuple[float, float, float] = (0.0, 1.0, 0.0)  # 绿色
    warning_performance: Tuple[float, float, float] = (1.0, 0.8, 0.0) # 黄色
    error_performance: Tuple[float, float, float] = (1.0, 0.0, 0.0) # 红色

class MaterialLibrary:
    """专业材质库"""
    
    def __init__(self):
        self.materials = {}
        self._create_professional_materials()
    
    def _create_professional_materials(self):
        """创建专业级材质"""
        
        # 发光材质 - 用于轨迹和重要元素
        self.materials['glowing'] = self._create_glowing_material()
        
        # 玻璃材质 - 用于扫掠体积可视化
        self.materials['glass'] = self._create_glass_material()
        
        # 金属材质 - 用于机器人和障碍物
        self.materials['metallic'] = self._create_metallic_material()
        
        # 全息材质 - 用于预测轨迹
        self.materials['hologram'] = self._create_hologram_material()
        
        # 粒子材质 - 用于特效
        self.materials['particle'] = self._create_particle_material()
        
        # HUD材质 - 用于UI元素
        self.materials['hud'] = self._create_hud_material()
    
    def _create_glowing_material(self) -> VisualMaterial:
        """创建发光材质"""
        material = VisualMaterial(
            visual_material_path="/World/Materials/GlowingMaterial",
            name="GlowingMaterial"
        )
        
        # 配置发光效果
        material.set_color(np.array([0.0, 0.8, 1.0]))
        material.set_roughness(0.0)
        material.set_metallic(0.9)
        material.set_opacity(0.8)
        
        # 添加自发光
        preview_surface = material.material.GetPrim()
        if preview_surface:
            material_shader = UsdShade.Material(preview_surface)
            if material_shader:
                surface_shader = material_shader.GetSurfaceOutput()
                if surface_shader:
                    # 设置发光强度
                    shader_prim = surface_shader.GetConnectedSource()[0].GetPrim()
                    if shader_prim:
                        shader = UsdShade.Shader(shader_prim)
                        shader.CreateInput("emissiveColor", Sdf.ValueTypeNames.Color3f).Set((0.0, 0.6, 0.8))
                        shader.CreateInput("emissiveIntensity", Sdf.ValueTypeNames.Float).Set(2.0)
        
        return material
    
    def _create_glass_material(self) -> VisualMaterial:
        """创建玻璃材质"""
        material = VisualMaterial(
            visual_material_path="/World/Materials/GlassMaterial", 
            name="GlassMaterial"
        )
        
        material.set_color(np.array([0.8, 0.9, 1.0]))
        material.set_roughness(0.05)
        material.set_metallic(0.0)
        material.set_opacity(0.3)
        material.set_ior(1.5)  # 玻璃折射率
        
        return material
    
    def _create_metallic_material(self) -> VisualMaterial:
        """创建金属材质"""
        material = VisualMaterial(
            visual_material_path="/World/Materials/MetallicMaterial",
            name="MetallicMaterial"
        )
        
        material.set_color(np.array([0.7, 0.7, 0.8]))
        material.set_roughness(0.2)
        material.set_metallic(0.9)
        material.set_opacity(1.0)
        
        return material
    
    def _create_hologram_material(self) -> VisualMaterial:
        """创建全息材质"""
        material = VisualMaterial(
            visual_material_path="/World/Materials/HologramMaterial",
            name="HologramMaterial"
        )
        
        material.set_color(np.array([0.0, 1.0, 0.8]))
        material.set_roughness(0.0)
        material.set_metallic(0.0)
        material.set_opacity(0.4)
        
        # 添加全息发光效果
        preview_surface = material.material.GetPrim()
        if preview_surface:
            material_shader = UsdShade.Material(preview_surface)
            if material_shader:
                surface_shader = material_shader.GetSurfaceOutput()
                if surface_shader:
                    shader_prim = surface_shader.GetConnectedSource()[0].GetPrim()
                    if shader_prim:
                        shader = UsdShade.Shader(shader_prim)
                        shader.CreateInput("emissiveColor", Sdf.ValueTypeNames.Color3f).Set((0.0, 0.8, 0.6))
                        shader.CreateInput("emissiveIntensity", Sdf.ValueTypeNames.Float).Set(1.5)
        
        return material
    
    def _create_particle_material(self) -> VisualMaterial:
        """创建粒子材质"""
        material = VisualMaterial(
            visual_material_path="/World/Materials/ParticleMaterial",
            name="ParticleMaterial"
        )
        
        material.set_color(np.array([1.0, 1.0, 1.0]))
        material.set_roughness(0.0)
        material.set_metallic(0.0)
        material.set_opacity(0.6)
        
        return material
    
    def _create_hud_material(self) -> VisualMaterial:
        """创建HUD材质"""
        material = VisualMaterial(
            visual_material_path="/World/Materials/HUDMaterial",
            name="HUDMaterial"
        )
        
        material.set_color(np.array([0.0, 1.0, 0.0]))
        material.set_roughness(0.0)
        material.set_metallic(0.0)
        material.set_opacity(0.8)
        
        return material
    
    def get_material(self, material_type: str) -> Optional[VisualMaterial]:
        """获取指定类型的材质"""
        return self.materials.get(material_type)
    
    def create_custom_material(self, color: Tuple[float, float, float], 
                             material_type: str = "glowing", 
                             intensity: float = 1.0) -> VisualMaterial:
        """创建自定义颜色的材质"""
        base_material = self.get_material(material_type)
        if not base_material:
            return self.get_material('glowing')
        
        # 创建新材质实例
        custom_material = VisualMaterial(
            visual_material_path=f"/World/Materials/Custom_{hash(color)}",
            name=f"Custom_{material_type}"
        )
        
        custom_material.set_color(np.array(color))
        
        if material_type == "glowing":
            custom_material.set_roughness(0.0)
            custom_material.set_metallic(0.9)
            custom_material.set_opacity(0.8)
            
            # 添加自发光
            preview_surface = custom_material.material.GetPrim()
            if preview_surface:
                material_shader = UsdShade.Material(preview_surface)
                if material_shader:
                    surface_shader = material_shader.GetSurfaceOutput()
                    if surface_shader:
                        shader_prim = surface_shader.GetConnectedSource()[0].GetPrim()
                        if shader_prim:
                            shader = UsdShade.Shader(shader_prim)
                            emissive_color = tuple(c * 0.8 for c in color)
                            shader.CreateInput("emissiveColor", Sdf.ValueTypeNames.Color3f).Set(emissive_color)
                            shader.CreateInput("emissiveIntensity", Sdf.ValueTypeNames.Float).Set(intensity)
        
        return custom_material

class LightingSystem:
    """动态光照系统"""
    
    def __init__(self, world: World):
        self.world = world
        self.lights = {}
        self._setup_professional_lighting()
    
    def _setup_professional_lighting(self):
        """设置专业级光照"""
        
        # 主环境光
        self._create_environment_light()
        
        # 聚光灯突出重要区域
        self._create_spotlight_system()
        
        # 氛围光增强视觉效果
        self._create_accent_lights()
    
    def _create_environment_light(self):
        """创建环境光"""
        env_light_path = "/World/Lighting/EnvironmentLight"
        env_light_prim = create_prim(env_light_path, "DomeLight")
        
        if env_light_prim:
            dome_light = UsdLux.DomeLight(env_light_prim)
            dome_light.CreateIntensityAttr(500)
            dome_light.CreateColorAttr(Gf.Vec3f(0.9, 0.95, 1.0))  # 冷白色
            
        self.lights['environment'] = env_light_prim
    
    def _create_spotlight_system(self):
        """创建聚光灯系统"""
        spotlight_configs = [
            {"name": "main_spot", "position": [0, 0, 8], "target": [0, 0, 0], "color": (1.0, 1.0, 1.0), "intensity": 1000},
            {"name": "side_spot", "position": [5, 5, 6], "target": [0, 0, 0], "color": (0.9, 0.95, 1.0), "intensity": 800},
        ]
        
        for config in spotlight_configs:
            light_path = f"/World/Lighting/{config['name']}"
            light_prim = create_prim(light_path, "SphereLight")
            
            if light_prim:
                sphere_light = UsdLux.SphereLight(light_prim)
                sphere_light.CreateIntensityAttr(config['intensity'])
                sphere_light.CreateColorAttr(Gf.Vec3f(*config['color']))
                sphere_light.CreateRadiusAttr(0.5)
                
                # 设置位置
                UsdGeom.Xformable(light_prim).AddTranslateOp().Set(Gf.Vec3d(*config['position']))
                
            self.lights[config['name']] = light_prim
    
    def _create_accent_lights(self):
        """创建氛围光"""
        accent_configs = [
            {"name": "accent_blue", "position": [-3, 0, 4], "color": (0.3, 0.7, 1.0), "intensity": 300},
            {"name": "accent_green", "position": [3, 0, 4], "color": (0.3, 1.0, 0.3), "intensity": 300},
        ]
        
        for config in accent_configs:
            light_path = f"/World/Lighting/{config['name']}"
            light_prim = create_prim(light_path, "SphereLight")
            
            if light_prim:
                sphere_light = UsdLux.SphereLight(light_prim)
                sphere_light.CreateIntensityAttr(config['intensity'])
                sphere_light.CreateColorAttr(Gf.Vec3f(*config['color']))
                sphere_light.CreateRadiusAttr(0.2)
                
                UsdGeom.Xformable(light_prim).AddTranslateOp().Set(Gf.Vec3d(*config['position']))
                
            self.lights[config['name']] = light_prim
    
    def update_dynamic_lighting(self, robot_position: Tuple[float, float, float]):
        """根据机器人位置更新动态光照"""
        if 'main_spot' in self.lights:
            # 主聚光灯跟随机器人
            light_position = [robot_position[0], robot_position[1] - 2, robot_position[2] + 5]
            light_prim = self.lights['main_spot']
            if light_prim:
                UsdGeom.Xformable(light_prim).GetTranslateOp().Set(Gf.Vec3d(*light_position))

class ParticleEffects:
    """粒子效果系统"""
    
    def __init__(self, world: World, material_library: MaterialLibrary):
        self.world = world
        self.material_library = material_library
        self.active_effects = {}
    
    def create_trajectory_particles(self, trajectory_points: List[Tuple[float, float, float]], 
                                  color: Tuple[float, float, float] = (0.0, 0.8, 1.0)) -> str:
        """创建轨迹粒子效果"""
        effect_id = f"trajectory_particles_{time.time()}"
        particles = []
        
        particle_material = self.material_library.create_custom_material(color, "particle", intensity=1.5)
        
        for i, point in enumerate(trajectory_points[::5]):  # 每5个点采样一个粒子
            particle_path = f"/World/Effects/TrajectoryParticles/{effect_id}/particle_{i}"
            
            # 创建小球粒子
            particle = VisualSphere(
                prim_path=particle_path,
                name=f"particle_{i}",
                position=np.array(point),
                radius=0.02,
                color=np.array(color)
            )
            
            if particle_material:
                particle.apply_visual_material(particle_material)
            
            particles.append(particle)
        
        self.active_effects[effect_id] = particles
        return effect_id
    
    async def animate_optimization_convergence(self, center_point: Tuple[float, float, float], 
                                            color: Tuple[float, float, float] = (0.0, 1.0, 0.3)):
        """动画化优化收敛效果"""
        effect_id = f"convergence_{time.time()}"
        particles = []
        
        # 创建收敛粒子群
        num_particles = 20
        for i in range(num_particles):
            angle = 2 * math.pi * i / num_particles
            radius = 2.0
            
            start_pos = [
                center_point[0] + radius * math.cos(angle),
                center_point[1] + radius * math.sin(angle),
                center_point[2] + 0.5
            ]
            
            particle_path = f"/World/Effects/Convergence/{effect_id}/particle_{i}"
            particle = VisualSphere(
                prim_path=particle_path,
                name=f"convergence_particle_{i}",
                position=np.array(start_pos),
                radius=0.01,
                color=np.array(color)
            )
            
            particles.append((particle, start_pos, center_point))
        
        # 动画化收敛过程
        steps = 50
        for step in range(steps):
            progress = step / steps
            
            for particle, start_pos, target_pos in particles:
                # 计算当前位置
                current_pos = [
                    start_pos[0] + (target_pos[0] - start_pos[0]) * progress,
                    start_pos[1] + (target_pos[1] - start_pos[1]) * progress,
                    start_pos[2] + (target_pos[2] - start_pos[2]) * progress
                ]
                
                particle.set_world_pose(position=np.array(current_pos))
                
                # 逐渐缩小粒子
                scale = 1.0 - progress * 0.8
                particle.set_local_scale(np.array([scale, scale, scale]))
            
            await asyncio.sleep(0.02)
        
        # 清理粒子
        for particle, _, _ in particles:
            if particle.prim:
                omni.usd.get_context().get_stage().RemovePrim(particle.prim.GetPath())
    
    def create_control_feedback_effect(self, robot_position: Tuple[float, float, float], 
                                     error_magnitude: float) -> str:
        """创建控制反馈效果"""
        effect_id = f"control_feedback_{time.time()}"
        
        # 根据误差大小选择颜色
        if error_magnitude < 0.1:
            color = (0.0, 1.0, 0.0)  # 绿色 - 好
        elif error_magnitude < 0.3:
            color = (1.0, 0.8, 0.0)  # 黄色 - 警告
        else:
            color = (1.0, 0.0, 0.0)  # 红色 - 错误
        
        # 创建光环效果
        ring_path = f"/World/Effects/ControlFeedback/{effect_id}/ring"
        ring_radius = 0.3 + error_magnitude * 2.0
        
        # 使用扁平圆环几何
        ring = VisualCylinder(
            prim_path=ring_path,
            name="control_ring",
            position=np.array([robot_position[0], robot_position[1], robot_position[2] + 0.1]),
            radius=ring_radius,
            height=0.02,
            color=np.array(color)
        )
        
        material = self.material_library.create_custom_material(color, "glowing", intensity=2.0)
        if material:
            ring.apply_visual_material(material)
        
        self.active_effects[effect_id] = [ring]
        return effect_id
    
    def cleanup_effect(self, effect_id: str):
        """清理特定效果"""
        if effect_id in self.active_effects:
            for obj in self.active_effects[effect_id]:
                if hasattr(obj, 'prim') and obj.prim:
                    omni.usd.get_context().get_stage().RemovePrim(obj.prim.GetPath())
            del self.active_effects[effect_id]
    
    def cleanup_all_effects(self):
        """清理所有效果"""
        for effect_id in list(self.active_effects.keys()):
            self.cleanup_effect(effect_id)

class PerformanceHUD:
    """性能监控HUD"""
    
    def __init__(self, world: World, material_library: MaterialLibrary):
        self.world = world
        self.material_library = material_library
        self.hud_elements = {}
        self.metrics = {}
        self._create_hud_layout()
    
    def _create_hud_layout(self):
        """创建HUD布局"""
        # HUD背景面板
        self._create_hud_panel()
        
        # 性能指标显示区域
        self._create_metrics_display()
        
        # 状态指示器
        self._create_status_indicators()
    
    def _create_hud_panel(self):
        """创建HUD背景面板"""
        panel_path = "/World/UI/HUD/Panel"
        panel = VisualCuboid(
            prim_path=panel_path,
            name="hud_panel",
            position=np.array([8, 0, 3]),
            size=np.array([3, 4, 0.1]),
            color=np.array([0.1, 0.1, 0.2])
        )
        
        panel_material = self.material_library.create_custom_material(
            (0.1, 0.1, 0.2), "glass", intensity=0.5
        )
        if panel_material:
            panel.apply_visual_material(panel_material)
        
        self.hud_elements['panel'] = panel
    
    def _create_metrics_display(self):
        """创建指标显示区域"""
        # 创建指标显示球体 (简化的数字显示)
        metrics_positions = [
            {"name": "planning_time", "pos": [8, 1.5, 3.5], "color": (0.3, 0.7, 1.0)},
            {"name": "optimization_time", "pos": [8, 0.5, 3.5], "color": (1.0, 0.8, 0.3)},
            {"name": "control_error", "pos": [8, -0.5, 3.5], "color": (1.0, 0.3, 0.8)},
            {"name": "computation_load", "pos": [8, -1.5, 3.5], "color": (0.3, 1.0, 0.3)},
        ]
        
        for metric in metrics_positions:
            indicator_path = f"/World/UI/HUD/Metrics/{metric['name']}"
            indicator = VisualSphere(
                prim_path=indicator_path,
                name=f"metric_{metric['name']}",
                position=np.array(metric['pos']),
                radius=0.1,
                color=np.array(metric['color'])
            )
            
            indicator_material = self.material_library.create_custom_material(
                metric['color'], "glowing", intensity=1.5
            )
            if indicator_material:
                indicator.apply_visual_material(indicator_material)
            
            self.hud_elements[f"metric_{metric['name']}"] = indicator
    
    def _create_status_indicators(self):
        """创建状态指示器"""
        status_positions = [
            {"name": "planning_status", "pos": [8.8, 1.5, 3.5]},
            {"name": "optimization_status", "pos": [8.8, 0.5, 3.5]},
            {"name": "control_status", "pos": [8.8, -0.5, 3.5]},
            {"name": "system_status", "pos": [8.8, -1.5, 3.5]},
        ]
        
        for status in status_positions:
            indicator_path = f"/World/UI/HUD/Status/{status['name']}"
            indicator = VisualCuboid(
                prim_path=indicator_path,
                name=f"status_{status['name']}",
                position=np.array(status['pos']),
                size=np.array([0.1, 0.1, 0.1]),
                color=np.array([0.5, 0.5, 0.5])  # 默认灰色
            )
            
            self.hud_elements[f"status_{status['name']}"] = indicator
    
    def update_metric(self, metric_name: str, value: float, status: str = "normal"):
        """更新指标显示"""
        self.metrics[metric_name] = {"value": value, "status": status}
        
        # 更新指标球体的大小表示数值
        metric_indicator = self.hud_elements.get(f"metric_{metric_name}")
        if metric_indicator:
            # 根据数值调整大小 (归一化到合理范围)
            scale_factor = min(max(value / 100.0, 0.1), 2.0)  # 限制在0.1-2.0之间
            metric_indicator.set_local_scale(np.array([scale_factor, scale_factor, scale_factor]))
        
        # 更新状态指示器颜色
        status_indicator = self.hud_elements.get(f"status_{metric_name}")
        if status_indicator:
            if status == "good":
                color = (0.0, 1.0, 0.0)  # 绿色
            elif status == "warning":
                color = (1.0, 0.8, 0.0)  # 黄色
            elif status == "error":
                color = (1.0, 0.0, 0.0)  # 红色
            else:
                color = (0.5, 0.5, 0.5)  # 灰色
            
            status_material = self.material_library.create_custom_material(color, "glowing")
            if status_material:
                status_indicator.apply_visual_material(status_material)
    
    def update_all_metrics(self, metrics_dict: Dict[str, Any]):
        """批量更新所有指标"""
        for metric_name, metric_data in metrics_dict.items():
            if isinstance(metric_data, dict):
                value = metric_data.get('value', 0.0)
                status = metric_data.get('status', 'normal')
            else:
                value = float(metric_data)
                status = 'normal'
            
            self.update_metric(metric_name, value, status)

class ProfessionalIsaacVisualizer:
    """专业级Isaac Sim可视化系统主类"""
    
    def __init__(self, world: World):
        self.world = world
        self.color_scheme = ColorScheme()
        
        # 初始化子系统
        self.material_library = MaterialLibrary()
        self.lighting_system = LightingSystem(world)
        self.particle_effects = ParticleEffects(world, self.material_library)
        self.performance_hud = PerformanceHUD(world, self.material_library)
        
        # 可视化对象存储
        self.visualization_objects = {}
        self.current_mode = VisualizationMode.PLANNING
        
        # 动画控制
        self.animation_tasks = []
        self.is_animating = False
        
        # 层次高度设置
        self.layer_heights = {
            'ground': 0.0,
            'obstacles': 0.1,
            'paths': 0.2,
            'trajectories': 0.3,
            'predictions': 0.4,
            'ui_elements': 0.5
        }
        
        print("专业级Isaac Sim可视化系统初始化完成")
    
    def set_visualization_mode(self, mode: VisualizationMode):
        """设置可视化模式"""
        self.current_mode = mode
        print(f"切换到可视化模式: {mode.value}")
    
    async def visualize_astar_search(self, grid_map: np.ndarray, 
                                   search_nodes: List[Dict], 
                                   final_path: List[Tuple[float, float]]):
        """可视化A*搜索过程"""
        print("开始A*搜索可视化...")
        
        # 清理之前的搜索可视化
        self._cleanup_category("astar_search")
        
        # 创建网格背景
        await self._create_search_grid(grid_map)
        
        # 动画化搜索过程
        await self._animate_search_process(search_nodes)
        
        # 显示最终路径
        await self._highlight_final_path(final_path)
        
        print("A*搜索可视化完成")
    
    async def _create_search_grid(self, grid_map: np.ndarray):
        """创建搜索网格"""
        grid_height, grid_width = grid_map.shape
        cell_size = 0.1
        
        for i in range(grid_height):
            for j in range(grid_width):
                if grid_map[i, j] == 0:  # 可通行区域
                    continue
                    
                cell_path = f"/World/Planning/AStarSearch/Grid/cell_{i}_{j}"
                cell_position = [j * cell_size, i * cell_size, self.layer_heights['ground']]
                
                # 根据网格值选择颜色
                if grid_map[i, j] == 1:  # 障碍物
                    color = self.color_scheme.obstacle
                else:  # 其他类型
                    color = (0.5, 0.5, 0.5)
                
                cell = VisualCuboid(
                    prim_path=cell_path,
                    name=f"grid_cell_{i}_{j}",
                    position=np.array(cell_position),
                    size=np.array([cell_size * 0.9, cell_size * 0.9, 0.02]),
                    color=np.array(color)
                )
                
                self.visualization_objects.setdefault("astar_search", []).append(cell)
    
    async def _animate_search_process(self, search_nodes: List[Dict]):
        """动画化搜索过程"""
        for i, node in enumerate(search_nodes):
            if i % 5 == 0:  # 每5个节点显示一次，控制动画速度
                node_path = f"/World/Planning/AStarSearch/Nodes/node_{i}"
                node_position = [node['x'], node['y'], self.layer_heights['paths'] + 0.05]
                
                # 根据节点状态选择颜色
                if node['status'] == 'open':
                    color = self.color_scheme.astar_nodes
                elif node['status'] == 'closed':
                    color = (0.8, 0.3, 0.3)
                else:  # current
                    color = (1.0, 1.0, 0.0)
                
                node_sphere = VisualSphere(
                    prim_path=node_path,
                    name=f"search_node_{i}",
                    position=np.array(node_position),
                    radius=0.03,
                    color=np.array(color)
                )
                
                # 应用发光材质
                material = self.material_library.create_custom_material(color, "glowing")
                if material:
                    node_sphere.apply_visual_material(material)
                
                self.visualization_objects.setdefault("astar_search", []).append(node_sphere)
                
                await asyncio.sleep(0.01)  # 控制动画速度
    
    async def _highlight_final_path(self, final_path: List[Tuple[float, float]]):
        """高亮显示最终路径"""
        if len(final_path) < 2:
            return
        
        # 创建路径线条
        for i in range(len(final_path) - 1):
            start_point = final_path[i]
            end_point = final_path[i + 1]
            
            # 计算线段中心和方向
            center = [(start_point[0] + end_point[0]) / 2, 
                     (start_point[1] + end_point[1]) / 2, 
                     self.layer_heights['paths']]
            
            length = math.sqrt((end_point[0] - start_point[0])**2 + 
                             (end_point[1] - start_point[1])**2)
            
            # 创建光束效果
            beam_path = f"/World/Planning/AStarSearch/FinalPath/segment_{i}"
            beam = VisualCylinder(
                prim_path=beam_path,
                name=f"path_segment_{i}",
                position=np.array(center),
                radius=0.02,
                height=length,
                color=np.array(self.color_scheme.astar_search)
            )
            
            # 旋转光束对齐路径方向
            angle = math.atan2(end_point[1] - start_point[1], end_point[0] - start_point[0])
            # 注意：这里需要Isaac Sim特定的旋转方法
            
            # 应用发光材质
            material = self.material_library.create_custom_material(
                self.color_scheme.astar_search, "glowing", intensity=2.0
            )
            if material:
                beam.apply_visual_material(material)
            
            self.visualization_objects.setdefault("astar_search", []).append(beam)
            
            await asyncio.sleep(0.1)  # 逐段显示效果
    
    async def visualize_minco_optimization(self, 
                                         initial_trajectory: List[Tuple[float, float, float]],
                                         stage1_result: List[Tuple[float, float, float]],
                                         stage2_result: List[Tuple[float, float, float]],
                                         final_trajectory: List[Tuple[float, float, float]]):
        """可视化MINCO优化过程"""
        print("开始MINCO优化可视化...")
        
        # 清理之前的优化可视化
        self._cleanup_category("minco_optimization")
        
        # 显示初始轨迹
        await self._create_trajectory_visualization(
            initial_trajectory, "initial", self.color_scheme.initial_path
        )
        
        await asyncio.sleep(1.0)
        
        # 显示阶段1优化结果
        await self._create_trajectory_visualization(
            stage1_result, "stage1", self.color_scheme.minco_stage1
        )
        
        # 创建优化收敛效果
        if stage1_result:
            center_point = stage1_result[len(stage1_result)//2]
            await self.particle_effects.animate_optimization_convergence(
                center_point, self.color_scheme.minco_stage1
            )
        
        await asyncio.sleep(1.0)
        
        # 显示阶段2优化结果
        await self._create_trajectory_visualization(
            stage2_result, "stage2", self.color_scheme.minco_stage2
        )
        
        if stage2_result:
            center_point = stage2_result[len(stage2_result)//2]
            await self.particle_effects.animate_optimization_convergence(
                center_point, self.color_scheme.minco_stage2
            )
        
        await asyncio.sleep(1.0)
        
        # 显示最终优化轨迹
        await self._create_trajectory_visualization(
            final_trajectory, "final", self.color_scheme.final_trajectory
        )
        
        # 创建轨迹粒子效果
        self.particle_effects.create_trajectory_particles(
            final_trajectory, self.color_scheme.final_trajectory
        )
        
        print("MINCO优化可视化完成")
    
    async def _create_trajectory_visualization(self, 
                                             trajectory: List[Tuple[float, float, float]], 
                                             stage_name: str, 
                                             color: Tuple[float, float, float]):
        """创建轨迹可视化"""
        if len(trajectory) < 2:
            return
        
        trajectory_objects = []
        
        # 创建轨迹点
        for i, point in enumerate(trajectory[::3]):  # 每3个点显示一个
            point_path = f"/World/Optimization/{stage_name}/points/point_{i}"
            point_sphere = VisualSphere(
                prim_path=point_path,
                name=f"{stage_name}_point_{i}",
                position=np.array([point[0], point[1], self.layer_heights['trajectories'] + 0.05]),
                radius=0.03,
                color=np.array(color)
            )
            
            material = self.material_library.create_custom_material(color, "glowing")
            if material:
                point_sphere.apply_visual_material(material)
            
            trajectory_objects.append(point_sphere)
            
            await asyncio.sleep(0.02)  # 逐点显示动画
        
        # 创建轨迹连线
        for i in range(len(trajectory) - 1):
            start_point = trajectory[i]
            end_point = trajectory[i + 1]
            
            center = [(start_point[0] + end_point[0]) / 2, 
                     (start_point[1] + end_point[1]) / 2, 
                     self.layer_heights['trajectories']]
            
            length = math.sqrt(sum((end_point[j] - start_point[j])**2 for j in range(3)))
            
            line_path = f"/World/Optimization/{stage_name}/lines/line_{i}"
            line = VisualCylinder(
                prim_path=line_path,
                name=f"{stage_name}_line_{i}",
                position=np.array(center),
                radius=0.01,
                height=length,
                color=np.array(color)
            )
            
            material = self.material_library.create_custom_material(color, "glowing", intensity=1.5)
            if material:
                line.apply_visual_material(material)
            
            trajectory_objects.append(line)
        
        self.visualization_objects.setdefault("minco_optimization", []).extend(trajectory_objects)
    
    async def visualize_swept_volume(self, 
                                   robot_poses: List[Dict],
                                   swept_boundary: List[Tuple[float, float]],
                                   density_field: np.ndarray = None):
        """可视化扫掠体积"""
        print("开始扫掠体积可视化...")
        
        # 清理之前的扫掠体积可视化
        self._cleanup_category("swept_volume")
        
        # 显示机器人姿态序列
        await self._visualize_robot_poses(robot_poses)
        
        # 显示扫掠边界
        await self._visualize_swept_boundary(swept_boundary)
        
        # 显示密度场
        if density_field is not None:
            await self._visualize_density_field(density_field)
        
        print("扫掠体积可视化完成")
    
    async def _visualize_robot_poses(self, robot_poses: List[Dict]):
        """可视化机器人姿态序列"""
        for i, pose in enumerate(robot_poses[::5]):  # 每5个姿态显示一个
            robot_path = f"/World/SweptVolume/RobotPoses/robot_{i}"
            
            # 创建简化的机器人表示
            robot_body = VisualCuboid(
                prim_path=robot_path,
                name=f"robot_pose_{i}",
                position=np.array([pose['x'], pose['y'], self.layer_heights['trajectories']]),
                size=np.array([0.6, 0.4, 0.2]),  # 机器人尺寸
                color=np.array(self.color_scheme.robot)
            )
            
            # 设置透明度表示时间顺序
            alpha = 0.3 + 0.7 * (i / len(robot_poses[::5]))
            material = self.material_library.create_custom_material(
                self.color_scheme.robot, "glass"
            )
            if material:
                robot_body.apply_visual_material(material)
            
            self.visualization_objects.setdefault("swept_volume", []).append(robot_body)
            
            await asyncio.sleep(0.05)
    
    async def _visualize_swept_boundary(self, swept_boundary: List[Tuple[float, float]]):
        """可视化扫掠边界"""
        if len(swept_boundary) < 3:
            return
        
        # 创建边界线条
        for i in range(len(swept_boundary)):
            start_point = swept_boundary[i]
            end_point = swept_boundary[(i + 1) % len(swept_boundary)]  # 闭合边界
            
            center = [(start_point[0] + end_point[0]) / 2, 
                     (start_point[1] + end_point[1]) / 2, 
                     self.layer_heights['trajectories'] + 0.1]
            
            length = math.sqrt((end_point[0] - start_point[0])**2 + 
                             (end_point[1] - start_point[1])**2)
            
            boundary_path = f"/World/SweptVolume/Boundary/segment_{i}"
            boundary_line = VisualCylinder(
                prim_path=boundary_path,
                name=f"boundary_segment_{i}",
                position=np.array(center),
                radius=0.02,
                height=length,
                color=np.array(self.color_scheme.swept_volume)
            )
            
            material = self.material_library.create_custom_material(
                self.color_scheme.swept_volume, "glowing", intensity=2.0
            )
            if material:
                boundary_line.apply_visual_material(material)
            
            self.visualization_objects.setdefault("swept_volume", []).append(boundary_line)
    
    async def _visualize_density_field(self, density_field: np.ndarray):
        """可视化密度场"""
        # 简化实现：在高密度区域放置指示器
        height, width = density_field.shape
        cell_size = 0.1
        
        for i in range(0, height, 3):  # 降采样显示
            for j in range(0, width, 3):
                density = density_field[i, j]
                if density > 0.1:  # 只显示有意义的密度值
                    position = [j * cell_size, i * cell_size, 
                              self.layer_heights['trajectories'] + 0.2]
                    
                    # 根据密度值调整颜色和大小
                    color_intensity = min(density, 1.0)
                    color = (color_intensity, 0.5, 1.0 - color_intensity)
                    size = 0.05 + density * 0.1
                    
                    density_path = f"/World/SweptVolume/DensityField/indicator_{i}_{j}"
                    density_indicator = VisualSphere(
                        prim_path=density_path,
                        name=f"density_{i}_{j}",
                        position=np.array(position),
                        radius=size,
                        color=np.array(color)
                    )
                    
                    material = self.material_library.create_custom_material(
                        color, "glowing", intensity=density * 2.0
                    )
                    if material:
                        density_indicator.apply_visual_material(material)
                    
                    self.visualization_objects.setdefault("swept_volume", []).append(density_indicator)
    
    async def visualize_mpc_control(self, 
                                  robot_position: Tuple[float, float, float],
                                  predicted_trajectory: List[Tuple[float, float, float]],
                                  reference_trajectory: List[Tuple[float, float, float]],
                                  control_error: float):
        """可视化MPC控制"""
        # 清理之前的MPC可视化
        self._cleanup_category("mpc_control")
        
        # 更新动态光照
        self.lighting_system.update_dynamic_lighting(robot_position)
        
        # 显示预测轨迹（全息效果）
        await self._create_prediction_trajectory(predicted_trajectory)
        
        # 显示参考轨迹
        await self._create_reference_trajectory(reference_trajectory)
        
        # 创建控制反馈效果
        self.particle_effects.create_control_feedback_effect(robot_position, control_error)
        
        # 更新性能HUD
        self.performance_hud.update_metric("control_error", control_error * 100, 
                                         "good" if control_error < 0.1 else 
                                         "warning" if control_error < 0.3 else "error")
    
    async def _create_prediction_trajectory(self, predicted_trajectory: List[Tuple[float, float, float]]):
        """创建预测轨迹可视化"""
        for i, point in enumerate(predicted_trajectory):
            # 透明度随时间递减
            alpha = 1.0 - (i / len(predicted_trajectory)) * 0.7
            
            pred_path = f"/World/Control/MPCPrediction/point_{i}"
            pred_point = VisualSphere(
                prim_path=pred_path,
                name=f"prediction_{i}",
                position=np.array([point[0], point[1], self.layer_heights['predictions']]),
                radius=0.02,
                color=np.array(self.color_scheme.mpc_prediction)
            )
            
            # 使用全息材质
            material = self.material_library.get_material("hologram")
            if material:
                pred_point.apply_visual_material(material)
            
            self.visualization_objects.setdefault("mpc_control", []).append(pred_point)
    
    async def _create_reference_trajectory(self, reference_trajectory: List[Tuple[float, float, float]]):
        """创建参考轨迹可视化"""
        for i in range(len(reference_trajectory) - 1):
            start_point = reference_trajectory[i]
            end_point = reference_trajectory[i + 1]
            
            center = [(start_point[0] + end_point[0]) / 2, 
                     (start_point[1] + end_point[1]) / 2, 
                     self.layer_heights['trajectories'] + 0.05]
            
            length = math.sqrt(sum((end_point[j] - start_point[j])**2 for j in range(3)))
            
            ref_path = f"/World/Control/ReferenceTrajectory/segment_{i}"
            ref_line = VisualCylinder(
                prim_path=ref_path,
                name=f"reference_{i}",
                position=np.array(center),
                radius=0.015,
                height=length,
                color=np.array(self.color_scheme.mpc_trajectory)
            )
            
            material = self.material_library.create_custom_material(
                self.color_scheme.mpc_trajectory, "glowing", intensity=1.2
            )
            if material:
                ref_line.apply_visual_material(material)
            
            self.visualization_objects.setdefault("mpc_control", []).append(ref_line)
    
    def update_performance_metrics(self, metrics: Dict[str, Any]):
        """更新性能指标"""
        self.performance_hud.update_all_metrics(metrics)
    
    def _cleanup_category(self, category: str):
        """清理指定类别的可视化对象"""
        if category in self.visualization_objects:
            for obj in self.visualization_objects[category]:
                if hasattr(obj, 'prim') and obj.prim:
                    try:
                        omni.usd.get_context().get_stage().RemovePrim(obj.prim.GetPath())
                    except:
                        pass  # 忽略清理错误
            del self.visualization_objects[category]
    
    def cleanup_all(self):
        """清理所有可视化对象"""
        for category in list(self.visualization_objects.keys()):
            self._cleanup_category(category)
        
        # 清理粒子效果
        self.particle_effects.cleanup_all_effects()
        
        print("所有可视化对象已清理")
    
    async def run_complete_visualization_demo(self):
        """运行完整的可视化演示"""
        print("开始完整可视化演示...")
        
        # 模拟数据（实际使用时替换为真实数据）
        demo_data = self._generate_demo_data()
        
        # 1. A*搜索阶段
        self.set_visualization_mode(VisualizationMode.PLANNING)
        await self.visualize_astar_search(
            demo_data['grid_map'],
            demo_data['search_nodes'],
            demo_data['initial_path']
        )
        
        await asyncio.sleep(3.0)
        
        # 2. MINCO优化阶段
        self.set_visualization_mode(VisualizationMode.OPTIMIZATION)
        await self.visualize_minco_optimization(
            demo_data['initial_trajectory'],
            demo_data['stage1_result'],
            demo_data['stage2_result'],
            demo_data['final_trajectory']
        )
        
        await asyncio.sleep(3.0)
        
        # 3. 扫掠体积可视化
        await self.visualize_swept_volume(
            demo_data['robot_poses'],
            demo_data['swept_boundary'],
            demo_data['density_field']
        )
        
        await asyncio.sleep(3.0)
        
        # 4. MPC控制阶段
        self.set_visualization_mode(VisualizationMode.EXECUTION)
        for i, (robot_pos, pred_traj, ref_traj, error) in enumerate(demo_data['mpc_sequence']):
            await self.visualize_mpc_control(robot_pos, pred_traj, ref_traj, error)
            
            # 更新性能指标
            metrics = {
                'planning_time': {'value': 15.2, 'status': 'good'},
                'optimization_time': {'value': 32.8, 'status': 'good'},
                'control_error': {'value': error * 100, 'status': 'good' if error < 0.1 else 'warning'},
                'computation_load': {'value': 45.3, 'status': 'good'}
            }
            self.update_performance_metrics(metrics)
            
            await asyncio.sleep(0.5)
        
        print("完整可视化演示完成!")
    
    def _generate_demo_data(self) -> Dict[str, Any]:
        """生成演示用的模拟数据"""
        # 网格地图
        grid_map = np.zeros((50, 50))
        grid_map[15:25, 20:30] = 1  # 障碍物
        grid_map[35:40, 10:20] = 1  # 另一个障碍物
        
        # A*搜索节点
        search_nodes = []
        for i in range(100):
            search_nodes.append({
                'x': np.random.uniform(0, 5),
                'y': np.random.uniform(0, 5),
                'status': 'open' if i % 3 == 0 else 'closed'
            })
        
        # 初始路径
        initial_path = [(0, 0), (1, 1), (2, 1.5), (3, 2), (4, 3), (5, 4)]
        
        # 轨迹数据
        t = np.linspace(0, 10, 50)
        x = 2 + 2 * np.cos(t * 0.5)
        y = 2 + 2 * np.sin(t * 0.5)
        z = np.ones_like(t) * 0.3
        
        initial_trajectory = list(zip(x, y, z))
        stage1_result = list(zip(x + 0.1 * np.sin(t), y + 0.1 * np.cos(t), z))
        stage2_result = list(zip(x + 0.05 * np.sin(t), y + 0.05 * np.cos(t), z))
        final_trajectory = list(zip(x, y, z))
        
        # 机器人姿态
        robot_poses = []
        for i in range(len(t)):
            robot_poses.append({
                'x': x[i], 'y': y[i], 'z': z[i],
                'theta': t[i] * 0.5
            })
        
        # 扫掠边界（简化的凸包）
        swept_boundary = [
            (x.min() - 0.3, y.min() - 0.2),
            (x.max() + 0.3, y.min() - 0.2),
            (x.max() + 0.3, y.max() + 0.2),
            (x.min() - 0.3, y.max() + 0.2)
        ]
        
        # 密度场
        density_field = np.random.random((50, 50)) * 0.5
        
        # MPC序列
        mpc_sequence = []
        for i in range(20):
            robot_pos = (x[i], y[i], z[i])
            pred_traj = [(x[i+j], y[i+j], z[i+j]) for j in range(min(10, len(x)-i))]
            ref_traj = [(x[i+j], y[i+j], z[i+j]) for j in range(min(5, len(x)-i))]
            error = 0.05 + 0.1 * np.random.random()
            mpc_sequence.append((robot_pos, pred_traj, ref_traj, error))
        
        return {
            'grid_map': grid_map,
            'search_nodes': search_nodes,
            'initial_path': initial_path,
            'initial_trajectory': initial_trajectory,
            'stage1_result': stage1_result,
            'stage2_result': stage2_result,
            'final_trajectory': final_trajectory,
            'robot_poses': robot_poses,
            'swept_boundary': swept_boundary,
            'density_field': density_field,
            'mpc_sequence': mpc_sequence
        }

# 使用示例和接口函数
async def demo_professional_visualization():
    """演示专业可视化系统"""
    from omni.isaac.core import World
    
    # 初始化Isaac Sim world
    world = World(stage_units_in_meters=1.0)
    world.scene.add_default_ground_plane()
    
    # 创建专业可视化系统
    visualizer = ProfessionalIsaacVisualizer(world)
    
    try:
        # 运行完整演示
        await visualizer.run_complete_visualization_demo()
        
        # 保持可视化一段时间
        await asyncio.sleep(10.0)
        
    except Exception as e:
        print(f"可视化演示出错: {e}")
    finally:
        # 清理
        visualizer.cleanup_all()
        world.stop()

if __name__ == "__main__":
    # 运行演示
    asyncio.run(demo_professional_visualization())
