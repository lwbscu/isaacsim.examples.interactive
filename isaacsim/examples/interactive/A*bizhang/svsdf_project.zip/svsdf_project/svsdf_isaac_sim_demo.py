#!/usr/bin/env python3
"""
SVSDF轨迹规划系统Isaac Sim演示脚本
完整展示扫掠体积感知轨迹规划的四个阶段
参考astar_interactive.py的正确模式
"""

from isaacsim import SimulationApp
simulation_app = SimulationApp({"headless": False})

import carb
import omni
import omni.appwindow
import omni.ui as ui
import omni.usd
import os
import numpy as np
import math
import time  # 添加time导入，移除asyncio
from queue import PriorityQueue
from scipy.spatial.transform import Rotation as R

# Isaac Sim imports (正确的导入方式)
from isaacsim.core.api import World
from isaacsim.core.api.objects import DynamicCuboid, FixedCuboid
from isaacsim.robot.wheeled_robots import DifferentialController
from isaacsim.core.utils.stage import add_reference_to_stage
from pxr import UsdGeom, Gf, Usd
import isaacsim.core.utils.prims as prim_utils

# 导入上级目录的SVSDF规划器
import sys
sys.path.append('/home/lwb/isaacsim/exts/isaacsim.examples.interactive/isaacsim/examples/interactive/A*bizhang')
from svsdf_planner import SVSDFPlanner, RobotParams, TrajectoryPoint

# 设置资源路径
asset_root = "/home/lwb/isaacsim_assets/Assets/Isaac/4.5"
carb.settings.get_settings().set("/persistent/isaac/asset_root/default", asset_root)

class SVSDFDemo:
    """SVSDF演示类"""
    
    def __init__(self):
        self.world = None
        self.planner = None
        self.demo_scenarios = []
        self._setup_demo_scenarios()
        
        # 机器人状态
        self.robot_prim = None
        self.robot_xform = None
        self.current_position = np.array([0.0, 0.0, 0.1])
        self.current_orientation = 0.0
        
        # 目标位置
        self.goal_pos = np.array([5.0, 3.0, 0.1])
        self.target_cube = None
        
        # 系统状态
        self.state = "IDLE"  # IDLE, PLANNING, EXECUTING
        self.current_path = []
        self.trajectory_markers = []
        self.swept_volume_markers = []
        
        # 键盘状态
        self.keys_pressed = set()
        
        # 轨迹执行相关
        self.current_trajectory = None
        self.trajectory_start_time = None
        self.trajectory_duration = 0.0
        
    def _setup_demo_scenarios(self):
        """设置演示场景"""
        
        # 场景1：简单导航
        self.demo_scenarios.append({
            'name': '简单导航',
            'description': '在开放空间中的基本导航',
            'start_pos': np.array([0.0, 0.0]),
            'goal_pos': np.array([5.0, 3.0]),
            'start_yaw': 0.0,
            'goal_yaw': np.pi/4,
            'obstacles': [
                {'type': 'circle', 'center': [2.5, 1.5], 'radius': 0.8}
            ]
        })
        
        # 场景2：多障碍物环境
        self.demo_scenarios.append({
            'name': '多障碍物导航',
            'description': '复杂多障碍物环境中的导航',
            'start_pos': np.array([0.0, 0.0]),
            'goal_pos': np.array([8.0, 6.0]),
            'start_yaw': 0.0,
            'goal_yaw': 0.0,
            'obstacles': [
                {'type': 'circle', 'center': [2.0, 1.0], 'radius': 0.6},
                {'type': 'circle', 'center': [4.0, 3.0], 'radius': 0.5},
                {'type': 'circle', 'center': [6.0, 2.0], 'radius': 0.7},
                {'type': 'rectangle', 'center': [3.0, 4.5], 'size': [1.5, 0.8]},
                {'type': 'rectangle', 'center': [7.0, 5.0], 'size': [1.0, 1.2]}
            ]
        })
        
        # 场景3：狭窄通道
        self.demo_scenarios.append({
            'name': '狭窄通道',
            'description': '需要精确规划的狭窄通道导航',
            'start_pos': np.array([0.0, 2.0]),
            'goal_pos': np.array([6.0, 2.0]),
            'start_yaw': 0.0,
            'goal_yaw': 0.0,
            'obstacles': [
                {'type': 'rectangle', 'center': [2.0, 1.0], 'size': [3.0, 0.4]},
                {'type': 'rectangle', 'center': [2.0, 3.0], 'size': [3.0, 0.4]},
                {'type': 'rectangle', 'center': [4.5, 1.0], 'size': [1.0, 0.4]},
                {'type': 'rectangle', 'center': [4.5, 3.0], 'size': [1.0, 0.4]}
            ]
        })
        
        # 场景4：U型转弯
        self.demo_scenarios.append({
            'name': 'U型转弯',
            'description': '测试大角度转弯的扫掠体积优化',
            'start_pos': np.array([0.0, 2.0]),
            'goal_pos': np.array([0.0, 2.0]),
            'start_yaw': 0.0,
            'goal_yaw': np.pi,  # 180度转弯
            'obstacles': [
                {'type': 'rectangle', 'center': [2.0, 0.8], 'size': [4.0, 0.4]},
                {'type': 'rectangle', 'center': [2.0, 3.2], 'size': [4.0, 0.4]},
                {'type': 'rectangle', 'center': [4.3, 2.0], 'size': [0.4, 2.8]}
            ]
        })
    
    async def initialize_isaac_sim(self):
        """初始化Isaac Sim环境"""
        print("正在初始化Isaac Sim环境...")
        
        # 创建世界 (参考astar_interactive.py模式)
        self.world = World(stage_units_in_meters=1.0)
        await self.world.initialize_simulation_context_async()
        
        # 设置物理参数
        self.world.get_physics_context().set_gravity(-9.81)
        self.world.get_physics_context().set_solver_type("TGS")
        
        # 添加地面
        self.world.scene.add_default_ground_plane()
        
        # 设置照明
        self._setup_lighting()
        
        # 设置相机
        self._setup_camera()
        
        # 初始化SVSDF规划器
        stage = omni.usd.get_context().get_stage()
        from svsdf_planner import SVSDFPlanner, RobotParams
        
        # 配置机器人参数
        robot_params = RobotParams(
            length=1.0,
            width=0.6,
            turning_radius=0.5,
            max_velocity=2.0,
            max_acceleration=1.0
        )
        
        self.planner = SVSDFPlanner(robot_params=robot_params)
        
        # 创建机器人和环境
        await self._create_robot()
        self._create_obstacles()
        
        # 设置键盘监听
        self._setup_keyboard_input()
        
        print("Isaac Sim环境初始化完成")
        print("控制说明:")
        print("- 方向键: 移动黄色目标点")
        print("- SPACE: 开始SVSDF轨迹规划")
        print("- R: 重置机器人位置")
        print("- 1-4: 切换演示场景")
    
    def _setup_lighting(self):
        """设置场景照明"""
        try:
            # 简化照明设置
            print("Using default lighting")
        except Exception as e:
            print(f"设置照明失败: {e}")
    
    def _setup_camera(self):
        """设置相机视角"""
        try:
            # 简化相机设置
            print("Using default camera view")
        except Exception as e:
            print(f"设置相机失败: {e}")
            
        except Exception as e:
            print(f"设置相机失败: {e}")
    
    def run_demo_scenario(self, scenario_index: int = 0):
        """运行指定的演示场景"""
        if scenario_index >= len(self.demo_scenarios):
            print(f"场景索引 {scenario_index} 超出范围")
            return
        
        scenario = self.demo_scenarios[scenario_index]
        print(f"\n{'='*50}")
        print(f"运行演示场景: {scenario['name']}")
        print(f"描述: {scenario['description']}")
        print(f"{'='*50}")
        
        # 加载场景配置
        self._load_scenario(scenario_index)
        
        # 等待物理稳定
        self._wait_for_stability()
        
        print("场景加载完成，使用SPACE键开始SVSDF轨迹规划")
        print("✓ 场景设置完成! 现在可以使用键盘控制进行交互式演示")
 def _wait_for_stability(self, duration: float = 2.0):
        """等待物理系统稳定"""
        print(f"等待物理系统稳定 ({duration}s)...")
        
        for _ in range(int(duration * 10)):
            self.world.step(render=False)
            time.sleep(0.1)
    
    def _display_performance_metrics(self, planning_result):
        """显示规划性能指标"""
        print(f"\n性能指标:")
        print(f"- 规划成功: {planning_result.success}")
        if hasattr(planning_result, 'planning_time'):
            print(f"- 规划时间: {planning_result.planning_time:.3f}秒")
        if hasattr(planning_result, 'path_length'):
            print(f"- 路径长度: {planning_result.path_length:.2f}米")
        if hasattr(planning_result, 'swept_volume'):
            print(f"- 扫掠体积: {planning_result.swept_volume:.3f}立方米")

    def _create_robot_sync(self):
        """创建机器人 - 同步版本"""
        try:
            print("创建机器人...")
            
            # 使用简单的立方体作为机器人
            robot_size = np.array([1.0, 0.6, 0.2])
            robot_prim_path = "/World/Robot"
            
            self.robot_prim = DynamicCuboid(
                prim_path=robot_prim_path,
                name="robot",
                position=self.current_position,
                size=robot_size,
                color=np.array([0.0, 0.8, 0.0])  # 绿色
            )
            
            # 添加到世界
            self.world.scene.add(self.robot_prim)
            
            print("机器人创建完成")
            
        except Exception as e:
            print(f"创建机器人失败: {e}")
            import traceback
            traceback.print_exc()

    async def _create_robot(self):
        """创建机器人"""
        try:
            print("创建机器人...")
            
            # 使用简单的立方体作为机器人
            robot_size = np.array([1.0, 0.6, 0.2])
            robot_prim_path = "/World/Robot"
            
            self.robot_prim = DynamicCuboid(
                prim_path=robot_prim_path,
                name="robot",
                position=self.current_position,
                size=robot_size,
                color=np.array([0.0, 0.8, 0.0])  # 绿色
            )
            
            # 添加到世界
            self.world.scene.add(self.robot_prim)
            
            print("机器人创建完成")
            
        except Exception as e:
            print(f"创建机器人失败: {e}")
            import traceback
            traceback.print_exc()

    def _create_obstacles(self):
        """创建障碍物"""
        try:
            print("创建障碍物...")
            
            # 创建一些简单的障碍物
            obstacle_positions = [
                [2.5, 1.5, 0.5],
                [4.0, 3.0, 0.5],
                [1.0, 4.0, 0.5]
            ]
            
            for i, pos in enumerate(obstacle_positions):
                obstacle = FixedCuboid(
                    prim_path=f"/World/Obstacle_{i}",
                    name=f"obstacle_{i}",
                    position=np.array(pos),
                    size=np.array([0.8, 0.8, 1.0]),
                    color=np.array([0.8, 0.2, 0.2])  # 红色
                )
                self.world.scene.add(obstacle)
            
            # 创建目标位置标记
            self.target_cube = FixedCuboid(
                prim_path="/World/Target",
                name="target",
                position=self.goal_pos,
                size=np.array([0.3, 0.3, 0.3]),
                color=np.array([1.0, 1.0, 0.0])  # 黄色
            )
            self.world.scene.add(self.target_cube)
            
            print("障碍物创建完成")
            
        except Exception as e:
            print(f"创建障碍物失败: {e}")
            import traceback
            traceback.print_exc()

    def _setup_keyboard_input(self):
        """设置键盘输入监听"""
        try:
            print("设置键盘输入监听...")
            
            # 获取应用窗口
            app_window = omni.appwindow.get_default_app_window()
            if app_window:
                keyboard_event = carb.input.acquire_input_interface().subscribe_to_keyboard_events(
                    app_window.get_keyboard(),
                    self._on_keyboard_event
                )
                print("键盘监听设置完成")
            else:
                print("无法获取应用窗口，键盘监听设置失败")
                
        except Exception as e:
            print(f"设置键盘监听失败: {e}")

    def _on_keyboard_event(self, event, *args, **kwargs):
        """键盘事件处理"""
        try:
            if event.type == carb.input.KeyboardEventType.KEY_PRESS:
                key = event.input
                
                # SPACE键开始规划
                if key == carb.input.KeyboardInput.SPACE:
                    print("开始SVSDF轨迹规划...")
                    self._start_svsdf_planning()
                
                # R键重置机器人
                elif key == carb.input.KeyboardInput.R:
                    print("重置机器人位置")
                    self.current_position = np.array([0.0, 0.0, 0.1])
                    if self.robot_prim:
                        self.robot_prim.set_world_pose(position=self.current_position)
                
                # 方向键移动目标
                elif key == carb.input.KeyboardInput.ARROW_UP:
                    self.goal_pos[1] += 0.5
                    if self.target_cube:
                        self.target_cube.set_world_pose(position=self.goal_pos)
                    print(f"目标位置: {self.goal_pos}")
                
                elif key == carb.input.KeyboardInput.ARROW_DOWN:
                    self.goal_pos[1] -= 0.5
                    if self.target_cube:
                        self.target_cube.set_world_pose(position=self.goal_pos)
                    print(f"目标位置: {self.goal_pos}")
                
                elif key == carb.input.KeyboardInput.ARROW_LEFT:
                    self.goal_pos[0] -= 0.5
                    if self.target_cube:
                        self.target_cube.set_world_pose(position=self.goal_pos)
                    print(f"目标位置: {self.goal_pos}")
                
                elif key == carb.input.KeyboardInput.ARROW_RIGHT:
                    self.goal_pos[0] += 0.5
                    if self.target_cube:
                        self.target_cube.set_world_pose(position=self.goal_pos)
                    print(f"目标位置: {self.goal_pos}")
                
                # 数字键切换场景
                elif key == carb.input.KeyboardInput.KEY_1:
                    self._load_scenario(0)
                elif key == carb.input.KeyboardInput.KEY_2:
                    self._load_scenario(1)
                elif key == carb.input.KeyboardInput.KEY_3:
                    self._load_scenario(2)
                elif key == carb.input.KeyboardInput.KEY_4:
                    self._load_scenario(3)
                    
        except Exception as e:
            print(f"键盘事件处理失败: {e}")

    def _start_svsdf_planning(self):
        """开始SVSDF轨迹规划 - 完整的4阶段算法"""
        try:
            print("\n" + "="*60)
            print("🚀 启动 SVSDF 轨迹优化算法")
            print("="*60)
            
            # 准备起点和终点
            start_pos = self.current_position[:2]  # 只使用x,y
            goal_pos = self.goal_pos[:2]
            start_yaw = self.current_orientation
            goal_yaw = 0.0  # 默认目标朝向
            
            print(f"📍 起点: ({start_pos[0]:.2f}, {start_pos[1]:.2f}), 朝向: {start_yaw:.2f}°")
            print(f"🎯 终点: ({goal_pos[0]:.2f}, {goal_pos[1]:.2f}), 朝向: {goal_yaw:.2f}°")
            
            # 创建障碍物地图（从当前场景）
            obstacles = self._extract_obstacles_from_scene()
            print(f"🚧 检测到 {len(obstacles)} 个障碍物")
            
            # === 阶段1: A* 初始路径规划 ===
            print(f"\n📍 阶段1: A* 初始路径搜索")
            start_time = time.time()
            
            # 使用A*算法获取初始路径
            initial_path = self.planner.find_initial_path(
                start=start_pos,
                goal=goal_pos,
                obstacles=obstacles
            )
            
            stage1_time = time.time() - start_time
            print(f"✓ A* 路径搜索完成: {len(initial_path)} 个路径点, 耗时: {stage1_time:.3f}s")
            
            if not initial_path:
                print("❌ A* 路径搜索失败，无法找到可行路径")
                return
            
            # 可视化初始A*路径
            self._visualize_astar_path(initial_path)
            
            # === 阶段2: MINCO 第一阶段 - 轨迹平滑化 ===
            print(f"\n🔄 阶段2: MINCO轨迹平滑化")
            start_time = time.time()
            
            # 生成平滑轨迹
            smooth_trajectory = self.planner.generate_smooth_trajectory(
                waypoints=initial_path,
                start_state=[start_pos[0], start_pos[1], start_yaw, 0.0, 0.0, 0.0],
                goal_state=[goal_pos[0], goal_pos[1], goal_yaw, 0.0, 0.0, 0.0]
            )
            
            stage2_time = time.time() - start_time
            print(f"✓ MINCO轨迹平滑化完成, 耗时: {stage2_time:.3f}s")
            print(f"  轨迹持续时间: {smooth_trajectory.total_duration:.2f}s")
            
            # 可视化平滑轨迹
            self._visualize_smooth_trajectory(smooth_trajectory)
            
            # === 阶段3: MINCO 第二阶段 - 扫掠体积最小化 ===
            print(f"\n🔬 阶段3: 扫掠体积优化")
            start_time = time.time()
            
            # 计算原始扫掠体积
            original_volume = self.planner.calculate_swept_volume(smooth_trajectory)
            print(f"  原始扫掠体积: {original_volume:.4f} m³")
            
            # 执行扫掠体积优化
            optimized_trajectory = self.planner.optimize_swept_volume(
                initial_trajectory=smooth_trajectory,
                obstacles=obstacles,
                max_iterations=50
            )
            
            # 计算优化后的扫掠体积
            optimized_volume = self.planner.calculate_swept_volume(optimized_trajectory)
            volume_reduction = (original_volume - optimized_volume) / original_volume * 100
            
            stage3_time = time.time() - start_time
            print(f"✓ 扫掠体积优化完成, 耗时: {stage3_time:.3f}s")
            print(f"  优化后扫掠体积: {optimized_volume:.4f} m³")
            print(f"  体积减少: {volume_reduction:.1f}%")
            
            # 可视化扫掠体积（使用圆环）
            self._visualize_swept_volume_rings(optimized_trajectory)
            
            # === 阶段4: 轨迹跟踪执行 ===
            print(f"\n🎬 阶段4: 轨迹跟踪执行")
            
            # 准备轨迹执行
            self.current_trajectory = optimized_trajectory
            self.trajectory_start_time = time.time()
            self.state = "EXECUTING"
            
            # 可视化最终轨迹
            self._visualize_final_trajectory(optimized_trajectory)
            
            # 显示性能总结
            total_time = stage1_time + stage2_time + stage3_time
            print(f"\n📊 SVSDF算法性能总结:")
            print(f"  阶段1 (A*搜索): {stage1_time:.3f}s")
            print(f"  阶段2 (轨迹平滑): {stage2_time:.3f}s") 
            print(f"  阶段3 (体积优化): {stage3_time:.3f}s")
            print(f"  总规划时间: {total_time:.3f}s")
            print(f"  最终轨迹时长: {optimized_trajectory.total_duration:.2f}s")
            print(f"  扫掠体积减少: {volume_reduction:.1f}%")
            
            # 开始执行轨迹
            print(f"🏃 开始执行优化轨迹...")
            self._execute_optimized_trajectory(optimized_trajectory)
            
        except Exception as e:
            print(f"❌ SVSDF规划失败: {e}")
            import traceback
            traceback.print_exc()
            self.state = "IDLE"

    def _extract_obstacles_from_scene(self):
        """从当前场景中提取障碍物信息"""
        obstacles = []
        
        # 获取当前场景的障碍物（这里使用预设的障碍物信息）
        current_scenario = self.demo_scenarios[0]  # 默认使用第一个场景
        
        for obs in current_scenario['obstacles']:
            if obs['type'] == 'circle':
                obstacles.append({
                    'type': 'circle',
                    'center': np.array(obs['center']),
                    'radius': obs['radius']
                })
            elif obs['type'] == 'rectangle':
                obstacles.append({
                    'type': 'rectangle', 
                    'center': np.array(obs['center']),
                    'size': np.array(obs['size'])
                })
        
        return obstacles

    def _visualize_astar_path(self, path):
        """可视化A*初始路径"""
        try:
            print("可视化A*路径...")
            
            # 清除之前的路径标记
            self._clear_trajectory_markers()
            
            # 创建A*路径点标记（红色小立方体）
            for i, point in enumerate(path):
                marker = FixedCuboid(
                    prim_path=f"/World/AStarMarker_{i}",
                    name=f"astar_marker_{i}",
                    position=np.array([point[0], point[1], 0.05]),
                    size=np.array([0.08, 0.08, 0.08]),
                    color=np.array([1.0, 0.0, 0.0])  # 红色
                )
                self.world.scene.add(marker)
                self.trajectory_markers.append(marker)
            
            print(f"A*路径可视化完成: {len(path)} 个路径点")
            
        except Exception as e:
            print(f"A*路径可视化失败: {e}")

    def _visualize_smooth_trajectory(self, trajectory):
        """可视化平滑轨迹"""
        try:
            print("可视化平滑轨迹...")
            
            # 采样轨迹点
            dt = 0.1  # 100ms 间隔
            t = 0.0
            points = []
            
            while t <= trajectory.total_duration:
                state = trajectory.get_state_at_time(t)
                points.append([state.x, state.y])
                t += dt
            
            # 创建平滑轨迹标记（绿色小立方体）
            for i, point in enumerate(points[::5]):  # 每5个点显示一个标记
                marker = FixedCuboid(
                    prim_path=f"/World/SmoothMarker_{i}",
                    name=f"smooth_marker_{i}",
                    position=np.array([point[0], point[1], 0.08]),
                    size=np.array([0.06, 0.06, 0.06]),
                    color=np.array([0.0, 1.0, 0.0])  # 绿色
                )
                self.world.scene.add(marker)
                self.trajectory_markers.append(marker)
            
            print(f"平滑轨迹可视化完成: {len(points)} 个采样点")
            
        except Exception as e:
            print(f"平滑轨迹可视化失败: {e}")

    def _visualize_swept_volume_rings(self, trajectory):
        """使用圆环可视化扫掠体积"""
        try:
            print("可视化扫掠体积圆环...")
            
            # 清除之前的扫掠体积标记
            self._clear_swept_volume_markers()
            
            # 采样轨迹点
            dt = 0.2  # 200ms 间隔
            t = 0.0
            
            while t <= trajectory.total_duration:
                state = trajectory.get_state_at_time(t)
                
                # 计算机器人在该时刻的扫掠半径
                velocity = np.sqrt(state.vx**2 + state.vy**2)
                angular_velocity = abs(state.omega)
                
                # 根据速度和角速度计算扫掠半径
                base_radius = 0.3  # 基础半径
                velocity_factor = min(velocity * 0.1, 0.2)  # 线速度影响
                angular_factor = min(angular_velocity * 0.1, 0.3)  # 角速度影响
                swept_radius = base_radius + velocity_factor + angular_factor
                
                # 创建圆环来表示扫掠体积
                self._create_swept_volume_ring(
                    center=[state.x, state.y, 0.02],
                    inner_radius=swept_radius * 0.7,
                    outer_radius=swept_radius,
                    index=int(t / dt)
                )
                
                t += dt
            
            print(f"扫掠体积圆环可视化完成")
            
        except Exception as e:
            print(f"扫掠体积可视化失败: {e}")

    def _create_swept_volume_ring(self, center, inner_radius, outer_radius, index):
        """创建表示扫掠体积的圆环"""
        try:
            # 创建圆环的近似表示（使用多个小立方体）
            num_segments = 16  # 圆环分段数
            
            for i in range(num_segments):
                angle = 2 * np.pi * i / num_segments
                
                # 外圆
                outer_x = center[0] + outer_radius * np.cos(angle)
                outer_y = center[1] + outer_radius * np.sin(angle)
                
                outer_marker = FixedCuboid(
                    prim_path=f"/World/SweptRing_{index}_outer_{i}",
                    name=f"swept_ring_{index}_outer_{i}",
                    position=np.array([outer_x, outer_y, center[2]]),
                    size=np.array([0.03, 0.03, 0.01]),
                    color=np.array([1.0, 0.5, 0.0])  # 橙色
                )
                self.world.scene.add(outer_marker)
                self.swept_volume_markers.append(outer_marker)
                
                # 内圆（可选，用于更清晰的圆环效果）
                if inner_radius > 0.05:
                    inner_x = center[0] + inner_radius * np.cos(angle)
                    inner_y = center[1] + inner_radius * np.sin(angle)
                    
                    inner_marker = FixedCuboid(
                        prim_path=f"/World/SweptRing_{index}_inner_{i}",
                        name=f"swept_ring_{index}_inner_{i}",
                        position=np.array([inner_x, inner_y, center[2]]),
                        size=np.array([0.02, 0.02, 0.01]),
                        color=np.array([1.0, 0.8, 0.0])  # 淡橙色
                    )
                    self.world.scene.add(inner_marker)
                    self.swept_volume_markers.append(inner_marker)
            
        except Exception as e:
            print(f"创建扫掠体积圆环失败: {e}")

    def _visualize_final_trajectory(self, trajectory):
        """可视化最终优化后的轨迹"""
        try:
            print("可视化最终轨迹...")
            
            # 采样轨迹点
            dt = 0.05  # 50ms 间隔，更精细
            t = 0.0
            points = []
            
            while t <= trajectory.total_duration:
                state = trajectory.get_state_at_time(t)
                points.append([state.x, state.y])
                t += dt
            
            # 创建最终轨迹标记（蓝色小立方体）
            for i, point in enumerate(points[::10]):  # 每10个点显示一个标记
                marker = FixedCuboid(
                    prim_path=f"/World/FinalMarker_{i}",
                    name=f"final_marker_{i}",
                    position=np.array([point[0], point[1], 0.12]),
                    size=np.array([0.04, 0.04, 0.04]),
                    color=np.array([0.0, 0.0, 1.0])  # 蓝色
                )
                self.world.scene.add(marker)
                self.trajectory_markers.append(marker)
            
            print(f"最终轨迹可视化完成: {len(points)} 个采样点")
            
        except Exception as e:
            print(f"最终轨迹可视化失败: {e}")

    def _execute_optimized_trajectory(self, trajectory):
        """执行优化后的轨迹"""
        try:
            print("开始执行优化轨迹...")
            
            # 存储轨迹执行相关信息
            self.current_trajectory = trajectory
            self.trajectory_start_time = time.time()
            self.trajectory_duration = trajectory.total_duration
            
            print(f"轨迹执行时长: {self.trajectory_duration:.2f}s")
            print("机器人将沿着优化轨迹移动...")
            
            # 在物理回调中会更新机器人位置
            
        except Exception as e:
            print(f"轨迹执行失败: {e}")

    def _clear_trajectory_markers(self):
        """清除轨迹标记"""
        try:
            for marker in self.trajectory_markers:
                self.world.scene.remove_object(marker.name)
            self.trajectory_markers.clear()
        except Exception as e:
            print(f"清除轨迹标记失败: {e}")

    def _clear_swept_volume_markers(self):
        """清除扫掠体积标记"""
        try:
            for marker in self.swept_volume_markers:
                self.world.scene.remove_object(marker.name)
            self.swept_volume_markers.clear()
        except Exception as e:
            print(f"清除扫掠体积标记失败: {e}")

    def update_robot_trajectory_following(self):
        """更新机器人轨迹跟踪（在物理回调中调用）"""
        try:
            if self.state == "EXECUTING" and self.current_trajectory and self.trajectory_start_time:
                current_time = time.time()
                elapsed_time = current_time - self.trajectory_start_time
                
                if elapsed_time <= self.trajectory_duration:
                    # 获取当前时刻的轨迹状态
                    state = self.current_trajectory.get_state_at_time(elapsed_time)
                    
                    # 更新机器人位置
                    new_position = np.array([state.x, state.y, 0.1])
                    if self.robot_prim:
                        self.robot_prim.set_world_pose(position=new_position)
                        self.current_position = new_position
                        self.current_orientation = state.yaw
                    
                    # 每秒打印一次进度
                    if int(elapsed_time * 4) % 4 == 0:  # 每0.25秒
                        progress = (elapsed_time / self.trajectory_duration) * 100
                        print(f"📈 轨迹执行进度: {progress:.1f}% - 位置: ({state.x:.2f}, {state.y:.2f})")
                
                else:
                    # 轨迹执行完成
                    print("✅ 轨迹执行完成!")
                    self.state = "IDLE"
                    self.current_trajectory = None
                    self.trajectory_start_time = None
                    
        except Exception as e:
            print(f"轨迹跟踪更新失败: {e}")

    # ...existing code...
def main():
    """主函数"""
    demo = SVSDFDemo()
    
    try:
        # 初始化Isaac Sim环境 - 使用同步方式
        print("正在初始化Isaac Sim环境...")
        
        # 创建世界 (参考astar_interactive.py模式)
        demo.world = World(stage_units_in_meters=1.0)
        demo.world.initialize_simulation_context()
        
        # 设置物理参数
        demo.world.get_physics_context().set_gravity(-9.81)
        demo.world.get_physics_context().set_solver_type("TGS")
        
        # 添加地面
        demo.world.scene.add_default_ground_plane()
        
        # 设置照明和相机
        demo._setup_lighting()
        demo._setup_camera()
        
        # 初始化SVSDF规划器
        from svsdf_planner import SVSDFPlanner, RobotParams
        
        # 配置机器人参数
        robot_params = RobotParams(
            length=1.0,
            width=0.6,
            turning_radius=0.5,
            max_velocity=2.0,
            max_acceleration=1.0
        )
        
        demo.planner = SVSDFPlanner(robot_params=robot_params)
        
        # 创建机器人和环境
        demo._create_robot_sync()
        demo._create_obstacles()
        
        # 设置键盘监听
        demo._setup_keyboard_input()
        
        # 加载默认场景
        demo._load_scenario(0)
        
        # 运行默认场景设置
        demo.run_demo_scenario(0)
        
        print("Isaac Sim环境初始化完成")
        print("控制说明:")
        print("- 方向键: 移动黄色目标点")
        print("- SPACE: 开始SVSDF轨迹规划")
        print("- R: 重置机器人位置")
        print("- 1-4: 切换演示场景")
        
        # 添加物理回调
        def physics_step(step_size):
            # 更新轨迹跟踪
            demo.update_robot_trajectory_following()
        
        demo.world.add_physics_callback("physics_step", physics_step)
        
        # 重置世界并开始仿真
        demo.world.reset()
        
        print("SVSDF演示系统启动完成!")
        
        # 主仿真循环
        start_time = time.time()
        while simulation_app.is_running():
            try:
                demo.world.step(render=True)
                
                # 安全退出机制
                if time.time() - start_time > 3600:  # 1小时后自动退出
                    print("最大仿真时间已达到")
                    break
                    
            except Exception as e:
                print(f"仿真过程中出错: {e}")
                import traceback
                traceback.print_exc()
                break
        
    except Exception as e:
        print(f"演示运行出错: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        # 清理并关闭仿真
        print("正在关闭仿真...")
        if demo.world:
            demo.world.stop()
        simulation_app.close()


if __name__ == "__main__":
    main()